package com.isport.kafka;

import org.springframework.stereotype.Component;

@Component
public class Consumer {

//	@KafkaListener(topics = { "wyx1" })
//	public void consumer1(String message) {
//		System.out.println("consumer1-message: " + message);
//	}
//
//	@KafkaListener(topics = { "wyx2" })
//	public void consumer2(String message) {
//		System.out.println("consumer2-message: " + message);
//	}

}
