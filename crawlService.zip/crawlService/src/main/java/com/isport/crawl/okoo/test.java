package com.isport.crawl.okoo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.junit.Test;

public class test {
	
	@Test
	public void testBeforeHour() {
		String pubDate = "比赛时间：2018-12-11 1:00 星期二";
		if(pubDate!=null && pubDate!="") {
			pubDate = pubDate.substring(5, 21).trim()+":00";
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			try {
				Date date = sdf.parse(pubDate);
				pubDate =  sdf.format(date);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
	}

}
