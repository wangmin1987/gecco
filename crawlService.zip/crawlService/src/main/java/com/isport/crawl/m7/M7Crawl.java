package com.isport.crawl.m7;

import org.springframework.stereotype.Service;

import com.geccocrawler.gecco.dynamic.DynamicGecco;

/**
 * 7m 抓取
 * 
 * @author 八斗体育
 *
 */
@Service
public class M7Crawl {

	public void register() {  
		// 新闻块spiderBean
		Class<?> newsBriefs = DynamicGecco.html().stringField("docUrl").csspath("a").attr("href").build()
				.stringField("pubDate").csspath("a + span").text().build().register();
		// 新闻列表spiderBean
		DynamicGecco.html().gecco(new String[] {"http://news.7m.com.cn/list/{id}/{page}.shtml","http://news.7m.com.cn/teams/517/","http://news.7m.com.cn/teams/517/{page}.shtml"}, "m7List")
				.requestField("request").request().build().listField("newsList", newsBriefs).csspath("div.n_tz ul li")
				.build()
				.register();
		Class<?> keyword = DynamicGecco.html().stringField("keyword").csspath("a").text().build().register();
		// 详情spiderBean
		DynamicGecco.html().gecco("http://news.7m.com.cn/news/{datetime}/{id}.shtml", "m7Detail")
				.requestField("request").request().build().stringField("content").csspath("html").build()
				.stringField("title").csspath("p.ba").text().build()
				.listField("keywords", keyword).csspath("p.bc a").build()
				.stringField("pubDate").csspath("p.bb").text().build().register(); 
	}
}
