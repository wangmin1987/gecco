package com.isport.crawl.sportscn;

import org.springframework.stereotype.Service;
 
import com.geccocrawler.gecco.dynamic.DynamicGecco;
/**
 * 华体网 http://we.sportscn.com/category-4.html
 * @author 八斗体育
 *
 */
@Service
public class SportscnCrawl {

	public void register() {
		// 新闻块spiderBean
				Class<?> newsBriefs = DynamicGecco.html().stringField("docUrl").csspath("ul.a3 ol a").attr("href").build()
						.stringField("pubDate").csspath("ul.a3 ol").text().build().register();
		// 列表页 spiderBean
		DynamicGecco.html()
				// 匹配地址
				.gecco(new String[] { "http://we.sportscn.com/category-{c}.html" ,"http://we.sportscn.com/category-{c}html-page-{p}.html"}, "sportscnList")
				.requestField("request").request().build()
				.listField("newsList", newsBriefs).csspath("div.wdls").build()
				.register();

		// 详情spiderBean
		DynamicGecco.html().gecco(new String[] { "http://we.sportscn.com/viewnews-{id}.html" }, "sportscnDetail")
				// 请求对象
				.requestField("request").request().build()
				// 网页内容
				.stringField("content").csspath("html").build()
				// 新闻标题
				.stringField("title").csspath("ul.title h1").text().build() 
				// 发布日期
				.stringField("pubDate").csspath("ol.date").text().build().register();

	}

}
