package com.isport.crawl.fox008;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.isport.Constants;
import com.isport.bean.NewsInfoBean;
import com.isport.crawl.AbstractDetailPipeLine;

@Service
public class FoxDetail extends AbstractDetailPipeLine{

	@Override
	protected void setParseParameter(NewsInfoBean newsInfoBean, JSONObject jo) throws Exception {
		// 获取标题
				String title = jo.getString("title");
				// 获取发布时间
				String pubDate = jo.getString("pubDate");
				//获取关键字
				
				int pos1 =  pubDate.indexOf("小编| ") + 4;
				pubDate = "20" + pubDate.substring(pos1);
				
				newsInfoBean.setTitle(title);
				newsInfoBean.setPub_date(pubDate);
	}

	@Override
	protected void setConstant(NewsInfoBean newsInfoBean) {
		newsInfoBean.setSource(Constants.NEWS_SOURCE_Fox008.value);
		newsInfoBean.setSource_icon(Constants.NEWS_ICON_Fox008.value);
		
	}

	@Override
	protected String getBodyExpession() {
		return "div[style=overflow:hidden;text-overflow:clip;font: 14px/1.5 Helvetica,Arial,宋体,sans-serif;width:730]";
	}

}
