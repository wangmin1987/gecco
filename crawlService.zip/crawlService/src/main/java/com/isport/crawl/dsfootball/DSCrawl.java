package com.isport.crawl.dsfootball;

import org.springframework.stereotype.Service;

import com.geccocrawler.gecco.dynamic.DynamicGecco;
@Service
public class DSCrawl {
	
	public void register() {
		Class<?> newsBriefs = DynamicGecco.html().stringField("docUrl").csspath("a").attr("href").build()
				.stringField("pubDate").csspath("p.newsListN2Time small").text().build().register();
		
		DynamicGecco.html()
		.gecco(new String[] { "https://www.dszuqiu.com/articles/transfer/{channel}","https://www.dszuqiu.com/articles/transfer"}, "dsList")
		.requestField("request").request().build().listField("newsList", newsBriefs).csspath("ul.newsListN2 li").build()
		.stringField("nextUrl").csspath("ul.pagination li:last-child a").attr("href").build().register();
	
		DynamicGecco.html().gecco(new String[] {"https://www.dszuqiu.com/articles/transfer/{id}.html"}, "dsDetail").requestField("request").request().build()
		.stringField("content").csspath("html").build()
		.stringField("title").csspath("h1").text().build()
		.stringField("pubDate").csspath("p.newsDatailTime span:eq(1)").text().build().register();
	}
}
