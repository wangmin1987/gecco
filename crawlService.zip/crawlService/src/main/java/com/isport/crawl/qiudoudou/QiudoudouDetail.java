package com.isport.crawl.qiudoudou;

import org.springframework.stereotype.Service;
 
import com.alibaba.fastjson.JSONObject;
import com.isport.Constants;
import com.isport.bean.NewsInfoBean;
import com.isport.crawl.AbstractDetailPipeLine;

@Service
public class QiudoudouDetail extends AbstractDetailPipeLine {

	@Override
	protected void setParseParameter(NewsInfoBean newsInfoBean, JSONObject jo) throws Exception {
		// 获取标题
		String title = jo.getString("title");
		// 获取发布时间
		String strPubDate = jo.getString("pubDate"); 
		// 设置标题
		newsInfoBean.setTitle(title); 
		// 设置抽取时间
		newsInfoBean.setPub_date(strPubDate);

	}

	@Override
	protected void setConstant(NewsInfoBean newsInfoBean) {
		newsInfoBean.setSource(Constants.NEWS_SOURCE_Qiudoudou.value);
		newsInfoBean.setSource_icon(Constants.NEWS_ICON_Qiudoudou.value); 
	}

	@Override
	protected String getBodyExpession() {
		return "article";
	}

}
