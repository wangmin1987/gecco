package com.isport.crawl.tengxun.broadcast;

import org.eclipse.jetty.util.security.Credential.MD5;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.isport.bean.MatchDataInfo;
import com.isport.kafka.Producer;

/**
 * 更新通知
 * @author 八斗体育
 *
 */
@Service
public class AdviceService extends MatchCrawl{

	private final String matchDataInfoTopic = "matchDataInfo";

	// kafka 操作
	@Autowired
	private Producer producer;

	public void advice(MatchDataInfo matchDataInfo) {
		String matchData = matchDataInfo.getMatchData();
		System.out.println(matchDataInfo.toString());
		String compareData = matchDataInfoService.findDataInfo(matchDataInfo);
		System.out.println("new:"+MD5.digest(matchData));
		System.out.println("old:"+MD5.digest(compareData));
		if(needAdvice(matchDataInfo)
				&&!MD5.digest(matchData).equals(MD5.digest(compareData))) { 
			System.out.println("send topic"); 
			System.out.println(new Gson().toJson(matchDataInfo));
			producer.send(matchDataInfoTopic, matchDataInfo.getId(), new Gson().toJson(matchDataInfo));
		}
	}
	
	private boolean needAdvice(MatchDataInfo matchDataInfo) {
		String dataType = matchDataInfo.getDataType();
		return dataType.equals("0")||dataType.equals("1");
	}

	public static void main(String[] args) {
		System.out.println(MD5.digest("123"));
		System.out.println(MD5.digest("124"));
		String a = "[{\"data\":\"大家好，欢迎来到雷速体育观看本场比赛直播,比赛即将开始\",\"position\":0,\"time\":\"\",\"type\":0},{\"data\":\"本场比赛场地情况：人工草坪\",\"position\":0,\"time\":\"\",\"type\":0},{\"data\":\"本场比赛天气情况：晴\",\"position\":0,\"time\":\"\",\"type\":0},{\"data\":\"随着主裁判一声哨响,上半场比赛开始.\",\"position\":0,\"time\":\"\",\"type\":10},{\"data\":\"13\u0027 - 13分钟，马圭获得本场第1个角球\",\"main\":1,\"position\":2,\"time\":\"13\u0027\",\"type\":2},{\"data\":\"14\u0027 - 第2个角球 - (泽维卡平联)\",\"main\":1,\"position\":1,\"time\":\"14\u0027\",\"type\":2},{\"data\":\"34\u0027 - 第1张黄牌，裁判出示了本场比赛的第一张黄牌，给了马圭\",\"main\":1,\"position\":2,\"time\":\"34\u0027\",\"type\":3},{\"data\":\"35\u0027 - 第1个进球！球进啦！泽维卡平联取得本场比赛领先！\",\"main\":1,\"position\":1,\"time\":\"35\u0027\",\"type\":1},{\"data\":\"45\u0027 - 随着裁判一声哨响，上半场结束，目前比分1-0\",\"position\":0,\"time\":\"45\u0027\",\"type\":11},{\"data\":\"51\u0027 - 第2张黄牌 - (泽维卡平联)\",\"main\":1,\"position\":1,\"time\":\"51\u0027\",\"type\":3},{\"data\":\"67\u0027 - 第3个角球 - (马圭)\",\"main\":1,\"position\":2,\"time\":\"67\u0027\",\"type\":2}]";
		JSONArray jsonArray = JSONArray.parseArray(a);
		System.out.println(jsonArray.toString());
	}

}
