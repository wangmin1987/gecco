package com.isport.crawl.tengxun.esports;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.geccocrawler.gecco.request.HttpGetRequest;
import com.geccocrawler.gecco.request.HttpRequest;
import com.isport.crawl.AbstractListPipeLine;

@Service
public class TxKplList extends AbstractListPipeLine {
	private static final Logger LOGGER = LoggerFactory.getLogger(TxKplList.class);

	@Override
	protected Object getList(JSONObject jo) {
		return jo.getJSONArray("newsList");
	}

	@Override
	protected long getNewsTime(Object obj) throws Exception {
		JSONObject item = JSONObject.parseObject(obj.toString());
		// 日期格式化 (11/16)
		String strPubDate = item.getString("pubDate");
		strPubDate = strPubDate.replace("/", "-");
		// 获取系统年
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
		Date date = new Date();
		String year = sdf.format(date);
		// 重构时间
		strPubDate = year + "-" + strPubDate;
		sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			return sdf.parse(strPubDate).getTime();
		} catch (ParseException e) {
			e.printStackTrace();
			LOGGER.error("日期格式化错误" + strPubDate);
		}
		return 0;
	}

	@Override
	protected String getNewsDocUrl(String baseUrl, Object obj) {
		JSONObject item = JSONObject.parseObject(obj.toString());
		return com.gargoylesoftware.htmlunit.util.UrlUtils.resolveUrl(baseUrl, item.getString("docUrl"));
	}

	@Override
	protected String getNextUrl(String url, String nextUrl, int page) {
		final int underline = url.lastIndexOf("_");
		return url.substring(0, underline) + "_" + page + ".shtml";
	}

	@Override
	protected void setRequestParameter(HttpRequest subRequest, Object obj) {
		JSONObject item = JSONObject.parseObject(obj.toString());
		// 日期格式化 (11/16) 转 2018-11-16 00:00
		String strPubDate = item.getString("pubDate");
		strPubDate = strPubDate.replace("/", "-");
		// 获取系统年
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
		Date date = new Date();
		String year = sdf.format(date);
		// 重构时间
		strPubDate = year + "-" + strPubDate + " 00:00";
		subRequest.addParameter("pubDate", strPubDate);
	}
}
