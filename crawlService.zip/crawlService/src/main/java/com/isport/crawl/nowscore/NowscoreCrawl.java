package com.isport.crawl.nowscore;

import org.springframework.stereotype.Service;

import com.geccocrawler.gecco.dynamic.DynamicGecco;

@Service
public class NowscoreCrawl {
	public void register() {
		Class<?> newsBriefs = DynamicGecco.html().stringField("docUrl").csspath("a").attr("href").build()
				.stringField("pubDate").csspath("em").text().build().register();
		
		DynamicGecco.html()
		.gecco(new String[] { "http://www.nowscore.com/?page={page}","http://www.nowscore.com/"}, "nowscoreList")
		.requestField("request").request().build().listField("newsList", newsBriefs).csspath("#ulList1 li").build()
		.stringField("nextUrl").csspath("ul.pagination li:last-child a").attr("href").build().register();
	
		DynamicGecco.html().gecco(new String[] {"http://www.nowscore.com/news/{id}.htm"}, "nowscoreDetail").requestField("request").request().build()
		.stringField("content").csspath("html").build()
		.stringField("title").csspath("h1").text().build()
		.stringField("pubDate").csspath("#divTitle2").text().build().register();
	}
}
