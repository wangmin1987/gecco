package com.isport.crawl.huanhuba;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.Test;

public class test {
	
	@Test
	public void testCrawl() {
	
		String strPubDate = "2018-12-6 3:00:03";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			System.out.println(sdf.parse(strPubDate).getTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

}
