package com.isport.crawl.newsnow;

import org.springframework.stereotype.Service;

import com.geccocrawler.gecco.dynamic.DynamicGecco; 

@Service
public class NewssnowCrawlv2{
	
	public void register() {
		// 新闻块spiderBean
		Class<?> newsBriefs = DynamicGecco.html().stringField("docUrl").csspath("a.hll").attr("href").build()
				.stringField("pubDate").csspath("span.time").text().build().register();
		// 新闻列表spiderBean
		DynamicGecco.html().gecco(new String[] { "https://www.newsnow.co.uk/h/Sport/Football#" }, "")
				.requestField("request").request().build().listField("newsList", newsBriefs).csspath("div.h1").build()
				.register();
		Class<?> keyword = DynamicGecco.html().stringField("keyword").csspath("a").text().build().register();
		// 详情spiderBean
		DynamicGecco.html()
				.gecco(new String[] { "https://www.independent.ie/sport/soccer/premier-league/{id}.html", 
				"https://www.bavarianfootballworks.com/{year}/{month}/{day}/{id}/{newid}",
				"https://www.dailymail.co.uk/wires/afp/article-{id}/{newsid}.html",
				"http://global.espn.com/soccer/blog/transfer-talk/{number}/{method}/{id}/{newsid}",
				"https://beta.theglobeandmail.com/sports/soccer/{newsid}/",
				"https://www.footballfancast.com/premier-league/chelsea/{newsid}",
				"https://www.express.co.uk/sport/football/{express}/{newsid}",
				"https://reddevilarmada.com/{year}/{month}/{day}/{newsid}/",
				"https://www.theguardian.com/football/video/{year}/dec/{month}/{newsid}",
				"https://www.whufc.com/news/articles/{year}/december/{month}/{newsid}",
				"https://www.newsshopper.co.uk/sport/{newsid}/",
				"https://www.nbcsports.com/video/{newsid}"}, "")
				.requestField("request").request().build().stringField("content").csspath("html").build()
				.stringField("title").csspath("div.text-title > h1").text().build().listField("keywords", keyword)
				.csspath("span.tag a").build().stringField("pubDate").csspath("#news-time").text().build().register();
	}
	
	public static void main(String[] args) {
//		 String content;
//		try {
//			content = ContentExtractor.getContentByURL("https://www.eveningtimes.co.uk/sport/rangers/news/17275183.steven-gerrard-fears-knock-on-effects-of-red-cards-could-hurt-rangers-in-the-long-run/");
//	        System.out.println(content);
//		} catch (Exception e) { 
//			e.printStackTrace();
//		} 
	}
}
