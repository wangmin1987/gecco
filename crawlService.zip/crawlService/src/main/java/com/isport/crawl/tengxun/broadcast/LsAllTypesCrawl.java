package com.isport.crawl.tengxun.broadcast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.isport.bean.MatchInfo;

/**
 * https://www.leisu.com/
 * 
 * @author 八斗体育
 *
 */
@Service
public class LsAllTypesCrawl extends MatchCrawl {

	@Autowired
	LsBasketBallCrawl lsBastketBallCrawl;

	@Autowired
	LsFootBallCrawl lsFootBallCrawl;
	
	public void crawlType() {
		String channel = channels.get("足球"),matchStatus = "1";
		List<MatchInfo> matchInfoes = matchInfoService.getAll(matchStatus,channel);
		System.out.println(matchInfoes.size());
		lsFootBallCrawl.crawl(matchInfoes);
		channel= channels.get("篮球");
		matchInfoes = matchInfoService.getAll(matchStatus, channel);
		lsBastketBallCrawl.crawl(matchInfoes);
	}
	
	public void crawlIn() {
		System.out.println("crawlIn");
		List<MatchInfo> matchInfos = matchInfoService.getAll("1");
		System.out.println(matchInfos.size());
		for (MatchInfo matchInfo : matchInfos) {
			try {
				String zqchannelId = channels.get("足球"), lqchannelId = channels.get("篮球"),
						miChannel = matchInfo.getChannelId();
				if (zqchannelId.equals(miChannel)) {
					lsFootBallCrawl.crawl(matchInfo);
				} else if (lqchannelId.equals(miChannel)) {
					lsBastketBallCrawl.crawl(matchInfo);
				}
				updateMatchStat(matchInfo);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

	}

	private void updateMatchStat(MatchInfo matchInfo) {
		// 未匹配到的过期数据更新
		String startDate = matchInfo.getStartDate();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			long time = sdf.parse(startDate).getTime();
			if (time + 12 * 1000 * 60 * 60 - System.currentTimeMillis() < 0) {
				String matchStat = "2", mid = matchInfo.getMid();
				matchInfoService.updateMatchStat(matchStat, mid);
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws ParseException {
		String startTime = "12-20 08:30", startTimem = "2018-12-20 08:30:00";
		Calendar cale = null;
		cale = Calendar.getInstance();
		int year = cale.get(Calendar.YEAR);
		startTime = year + "-" + startTime;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		long start = sdf.parse(startTime).getTime();
		sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		long startm = sdf.parse(startTimem).getTime();
		System.out.println(startTime + "," + start);
		System.out.println(startTimem + "," + startm);
	}
}
