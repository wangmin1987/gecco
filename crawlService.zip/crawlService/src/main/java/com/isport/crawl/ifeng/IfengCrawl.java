package com.isport.crawl.ifeng;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.gargoylesoftware.htmlunit.util.UrlUtils;
import com.geccocrawler.gecco.dynamic.DynamicGecco;

/**
 * 凤凰体育 http://sports.ifeng.com/gjzq/
 * 
 * @author 八斗体育
 *
 */
@Service
public class IfengCrawl {
	public static void main(String[] args) {
		System.out.println(UrlUtils.resolveUrl("https://sports.ifeng.com/c/7iU4JWaIZgK", "http://e0.ifengimg.com/03/2018/1210/CFCFD040705F7FB8714B8CA5EA7DACAF28CFB567_size1354_w741_h467.png"));
	}

	public void register() {
		DynamicGecco.html().gecco(new String[] { "http://sports.ifeng.com/{fb}/" }, "ifengList").requestField("request")
				.request().build().field("newsList", JSONArray.class).jsvar("allData", "$.newsstream").build()
				.register();

		DynamicGecco.json().gecco(new String[] {
				"http://shankapi.ifeng.com/shanklist/_/getColumnInfo/_/default/{id}/{time}/20/11-35121-/getColumnInfoCallback?callback=getColumnInfoCallback" },
				"ifengList2").requestField("request").request().build().field("newsList", String.class)
				.renderName("ifengRender").build().register();

		DynamicGecco.html().gecco(new String[] { "https://sports.ifeng.com/c/{id}" }, "ifengDetail")
				.requestField("request").request().build().stringField("content").csspath("html").build()
				.field("newsList", JSONObject.class).jsvar("allData", "$.docData").build()
				.register();
	}

}
