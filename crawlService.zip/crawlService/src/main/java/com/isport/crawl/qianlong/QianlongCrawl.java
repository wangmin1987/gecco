package com.isport.crawl.qianlong;

import org.springframework.stereotype.Service;

import com.geccocrawler.gecco.dynamic.DynamicGecco;

/**
 * 千龙网 http://sports.qianlong.com/yingchao/
 * 
 * @author 八斗体育
 *
 */
@Service
public class QianlongCrawl {

	public void register() {
		Class<?> lisBriefs = DynamicGecco.html().stringField("docUrl").csspath("a").attr("href").build()
				.stringField("pubDate").csspath("span").text().build().register();
		DynamicGecco.html().gecco(new String[] { "http://sports.qianlong.com/{team}/{page}.shtml" }, "qianlongList")
				.requestField("request").request().build().listField("newsList", lisBriefs).csspath("ul.list6 li")
				.build().register();

		DynamicGecco.html()
				.gecco(new String[] { "http://sports.qianlong.com/{year}/{day}/{id}.shtml" }, "qianlongDetail")
				.requestField("request").request().build().stringField("content").csspath("html").build()
				.stringField("title").csspath("div.span12 h1").text().build().stringField("pubDate")
				.csspath("p.blockInfo span").text().build().register();
	}
}
