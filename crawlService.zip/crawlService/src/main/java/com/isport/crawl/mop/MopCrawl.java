package com.isport.crawl.mop;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.geccocrawler.gecco.dynamic.DynamicGecco;

@Service
public class MopCrawl {
	public void register() {
		// 列表页 spiderBean
		DynamicGecco.json().requestField("request").request().build()
				// 匹配地址
				.gecco(new String[] { "http://sports.mop.com/data/mop/news_{id}.js" },
						"mopList")
				.field("hot", JSONArray.class).jsonpath("$.hot").build()
				.field("news", JSONArray.class).jsonpath("$.news").build() 
				.register();
		
		Class<?> keyword = DynamicGecco.html().stringField("keyword").csspath("a").text().build().register();
		// 详情spiderBean
		DynamicGecco.html().gecco(new String[] { "http://sports.mop.com/a/{id}.html" }, "mopDetail")
				// 请求对象
				.requestField("request").request().build()
				// 网页内容
				.stringField("content").csspath("html").build()
				// 新闻标题
				.stringField("title").csspath("h1.tit").text().build()
				.listField("keywords", keyword).csspath("div.links span").build()
				// 发布日期
				.stringField("pubDate").csspath("p.fl").text().build().register();

	}

}
