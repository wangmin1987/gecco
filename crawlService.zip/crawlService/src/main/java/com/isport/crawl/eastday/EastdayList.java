package com.isport.crawl.eastday;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.isport.crawl.AbstractListPipeLine;
import com.isport.utils.StringUtils;

@Service
public class EastdayList extends AbstractListPipeLine {

	@SuppressWarnings("unchecked")
	@Override
	protected Object getList(JSONObject jo) throws Exception {
		String newsList = jo.getObject("newsList", String.class);
		int index = newsList.indexOf("(");
		newsList = newsList.substring(index + 1, newsList.length() - 1);
		JSONObject obj = JSONObject.parseObject(newsList);
		List<Object> news = new ArrayList<Object>();
		news.addAll(obj.getObject("top", List.class));
		news.addAll(obj.getObject("ku", List.class));
		return news;
	}

	@Override
	protected long getNewsTime(Object obj) throws Exception {
		// 转换对象为JSONObject
		JSONObject item = JSONObject.parseObject(obj.toString());
		String strPubDate = item.getString("date");
		if (StringUtils.isNUll(strPubDate)) {
			throw new Exception("非新闻内容");
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			// 日期字符串转换为时间戳
			return sdf.parse(strPubDate).getTime();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	protected String getNewsDocUrl(String baseUrl, Object obj) {
		// 转换对象为JSONObject
		JSONObject item = JSONObject.parseObject(obj.toString());
		return item.getString("url");
	}

	@Override
	protected String getNextUrl(String url, String nextUrl, int page) {
		return ILLEGAL_URL;
	}

}
