package com.isport.crawl.zqzz;

import org.springframework.stereotype.Service;

import com.geccocrawler.gecco.dynamic.DynamicGecco;

@Service
public class ZqzzCrawl {

	public void register() {
		Class<?> newsBriefs = DynamicGecco.html().stringField("docUrl").csspath("dt.pre-news-title a").attr("href").build()
				.stringField("pubDate").csspath("p.pre-news-date").text().build().register();
		
		DynamicGecco.html()
		.gecco(new String[] { "http://www.zqzz.com/pre/c/1","http://www.zqzz.com/pre/c/1/{page}"}, "zqzzList")
		.requestField("request").request().build().listField("newsList", newsBriefs).csspath("div.pre-news dl").build()
		.stringField("nextUrl").csspath("div.Page a:contains('下一页')").attr("href").build().register();
	
		DynamicGecco.html().gecco(new String[] {"http://www.zqzz.com/pre/{id}.html"}, "zqzzDetail").requestField("request").request().build()
		.stringField("content").csspath("html").build()
		.stringField("title").csspath("h1").text().build()
		.stringField("pubDate").csspath("div.Mc dt").text().build().register();
	}
}
