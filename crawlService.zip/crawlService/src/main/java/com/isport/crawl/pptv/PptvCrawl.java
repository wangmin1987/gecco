package com.isport.crawl.pptv;

import org.springframework.stereotype.Service;
 
import com.geccocrawler.gecco.dynamic.DynamicGecco;
/**
 * pp 体育抓取
 * http://sports.pptv.com/premierleague
 * @author 八斗体育
 *
 */
@Service
public class PptvCrawl {
	

	public void register() {
		// 列表页 spiderBean
		DynamicGecco.json().requestField("request").request().build()
				// 匹配地址
				.gecco(new String[] { "http://snsis.suning.com/snsis-web/client/queryInforList/{id}.htm?_callback={channel}" },
						"pptvList")
				.field("newsList", String.class).renderName("pptvRender").build() 
				.register();
		
		// 详情spiderBean
		DynamicGecco.json().gecco(new String[] { "http://snsis.suning.com/snsis-web/client/queryContentDetails/{contentId}/1/pc/0.0/1.1.htm?_callback=callback&callback=callback" }, "pptvDetail")
				// 请求对象
				.requestField("request").request().build() 
				.field("newsDetail", String.class).renderName("pptvRender").build()
				.register();
	}


}
