package com.isport.crawl.qi24;

import org.springframework.stereotype.Service;

import com.geccocrawler.gecco.dynamic.DynamicGecco;

/**
 * 爱球网 http://www.24iq.com/down_list.aspx?id=17&page=0
 * 
 * @author 八斗体育
 *
 */
@Service
public class Qi24Crawl {

	public void register() {
		Class<?> lisBriefs = DynamicGecco.html().stringField("docUrl").csspath("a").attr("href").build()
				.stringField("pubDate").csspath("span").text().build().register();
		DynamicGecco.html().gecco(new String[] { "http://www.24iq.com/down_list.aspx?id={id}&page={page}" }, "qi24List")
				.requestField("request").request().build().listField("newsList", lisBriefs).csspath("ul.newslist2 li")
				.build().register();

		DynamicGecco.html()
				.gecco(new String[] { "http://www.24iq.com/detail.aspx?id={id}" }, "qi24Detail")
				.requestField("request").request().build().stringField("content").csspath("html").build()
				.stringField("title").csspath("#ctl00_ContentPlaceHolder1_newstitle").text().build().stringField("pubDate")
				.csspath("#ctl00_ContentPlaceHolder1_newsabout").text().build().register();
	}
}
