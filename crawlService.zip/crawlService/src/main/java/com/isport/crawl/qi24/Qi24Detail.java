package com.isport.crawl.qi24;
 
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.geccocrawler.gecco.request.HttpRequest;
import com.isport.Constants;
import com.isport.bean.NewsInfoBean;
import com.isport.crawl.AbstractDetailPipeLine;

@Service
public class Qi24Detail extends AbstractDetailPipeLine {
	
	// request 参数设置
	protected void setRequestParameters(HttpRequest request, NewsInfoBean newsInfoBean) {
		String indexUrl = request.getParameter("index_url");
		String tag = request.getParameter("tag");
		String authorId = request.getParameter("author_id");
		String channelId = request.getParameter("custom_channel_id");
		newsInfoBean.setIndex_url(indexUrl);
		newsInfoBean.setTag(tag);
		newsInfoBean.setAuthor_id(authorId);
		newsInfoBean.setChannel_id(channelId);
	}
	
	@Override
	protected void setParseParameter(NewsInfoBean newsInfoBean, JSONObject jo) throws Exception {
		// 获取标题
		String title = jo.getString("title");
		// 获取发布时间
		String pubDate = jo.getString("pubDate");
		int lyIndex = pubDate.indexOf("来源");
		pubDate = pubDate.substring(0, lyIndex);
		pubDate = pubDate.trim();
		pubDate = pubDate.substring(0,10);
		pubDate = pubDate + " 00:00:00"; 
		newsInfoBean.setTitle(title);
		newsInfoBean.setPub_date(pubDate); 
	}
	  
	@Override
	protected void setConstant(NewsInfoBean newsInfoBean) {
		newsInfoBean.setSource(Constants.NEWS_SOURCE_IQ24.value);
		newsInfoBean.setSource_icon(Constants.NEWS_ICON_IQ24.value);
	}

	@Override
	protected String getBodyExpession() {
		return "#ctl00_ContentPlaceHolder1_newsdetail";
	}
	 
}
