package com.isport.crawl.pptv;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.stereotype.Service;
import com.alibaba.fastjson.JSONObject;
import com.isport.crawl.AbstractListPipeLine;

@Service
public class PptvList extends AbstractListPipeLine {

	@Override
	protected Object getList(JSONObject jo) throws Exception {
		String newsList = jo.getObject("newsList", String.class);
		int index = newsList.indexOf("(");
		newsList = newsList.substring(index + 1, newsList.length() - 1); 
		JSONObject obj = JSONObject.parseObject(newsList);
		return obj.getJSONObject("data").getJSONArray("contentList");
	}

	@Override
	protected long getNewsTime(Object obj) throws Exception {
		// 转换对象为JSONObject
		JSONObject item = JSONObject.parseObject(obj.toString());
		return Long.valueOf(item.getString("updateTimestamp"));
	}
	
	public static void main(String[] args) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			System.out.println(sdf.parse("2018-12-17 16:26:55").getTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected String getNewsDocUrl(String baseUrl, Object obj) {
		// 转换对象为JSONObject
		JSONObject item = JSONObject.parseObject(obj.toString()); 
//		return "http://sports.pptv.com/article/pg_detail?aid=" + item.getString("contentId") + "&type=article";
		return "http://snsis.suning.com/snsis-web/client/queryContentDetails/"+item.getString("contentId")+"/1/pc/0.0/1.1.htm?_callback=callback&callback=callback";
	}

	@Override
	protected String getNextUrl(String url, String nextUrl, int page) {
		return ILLEGAL_URL;
	}

}
