package com.isport.crawl.mop;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.gargoylesoftware.htmlunit.util.UrlUtils;
import com.geccocrawler.gecco.request.HttpRequest;
import com.isport.Constants;
import com.isport.bean.NewsInfoBean;
import com.isport.crawl.AbstractDetailPipeLine;

@Service
public class MopDetail extends AbstractDetailPipeLine {

	// request 参数设置
	protected void setRequestParameters(HttpRequest request, NewsInfoBean newsInfoBean) {
		String indexUrl = request.getParameter("index_url");
		String tag = request.getParameter("tag");
		String authorId = request.getParameter("author_id");
		String channelId = request.getParameter("custom_channel_id");
		newsInfoBean.setIndex_url(indexUrl);
		newsInfoBean.setTag(tag);
		newsInfoBean.setAuthor_id(authorId);
		newsInfoBean.setChannel_id(channelId);
	}

	@Override
	protected void setParseParameter(NewsInfoBean newsInfoBean, JSONObject jo) throws Exception {
		// 获取标题
		String title = jo.getString("title");
		// 获取发布时间
		String strPubDate = jo.getString("pubDate");
		// 获取关键字
		JSONArray keywords = jo.getJSONArray("keywords");
		StringBuilder keywordBuilder = new StringBuilder();
//				LOGGER.info("keywords size:"+keywords.size());
		for (Object keyword : keywords) {
			JSONObject item = JSONObject.parseObject(keyword.toString());
			keywordBuilder.append(item.getString("keyword"));
			keywordBuilder.append(" ");
		}
		// 设置标题
		newsInfoBean.setTitle(title);
		// 设置抽取时间
		newsInfoBean.setPub_date(strPubDate);
		// 设置关键字
		newsInfoBean.setKey_word(keywordBuilder.toString());
	}

	@Override
	protected void setConstant(NewsInfoBean newsInfoBean) {
		newsInfoBean.setSource(Constants.NEWS_SOURCE_MOP.value);
		newsInfoBean.setSource_icon(Constants.NEWS_ICON_MOP.value);
	}

	@Override
	protected String getBodyExpession() {
		return "div.txt.mt15";
	}

	@Override
	protected void processImage(NewsInfoBean newsInfoBean) {
		String url = newsInfoBean.getUrl();
		List<String> imgs = new ArrayList<String>();
		List<String> title_imgs = newsInfoBean.getTitle_imgs();
		for (String img : title_imgs) {
			imgs.add(UrlUtils.resolveUrl(url, img));
		}
		newsInfoBean.setTitle_imgs(imgs);
	}
}
