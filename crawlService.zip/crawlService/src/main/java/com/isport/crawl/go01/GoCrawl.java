package com.isport.crawl.go01;

import org.springframework.stereotype.Service;

import com.geccocrawler.gecco.dynamic.DynamicGecco;

@Service
public class GoCrawl {

	public void register() {
		Class<?> newsBriefs = DynamicGecco.html().stringField("docUrl").csspath("a").attr("href").build()
				.stringField("pubDate").csspath("span.date").text().build().register();
		
		DynamicGecco.html()
		.gecco(new String[] { "http://www.go01.com/jiepan/baoliao/","http://www.go01.com/jiepan/baoliao/index_{page}.html"}, "goList")
		.requestField("request").request().build().listField("newsList", newsBriefs).csspath("div.dir-txt li").build()
		.stringField("nextUrl").csspath("ul.pagination li:last-child a").attr("href").build().register();
	
		DynamicGecco.html().gecco(new String[] {"http://www.go01.com/jiepan/baoliao/{year}/{month}/{id}.html"}, "goDetail").requestField("request").request().build()
		.stringField("content").csspath("html").build()
		.stringField("title").csspath("h1").text().build()
		.stringField("pubDate").csspath("p.canshu").text().build().register();
	}
}
