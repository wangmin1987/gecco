package com.isport.crawl.qiudoudou;
  
import org.springframework.stereotype.Service; 
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.isport.crawl.AbstractListPipeLine;

@Service
public class QiudoudouList extends AbstractListPipeLine {

	@Override
	protected Object getList(JSONObject jo) throws Exception {
		String newsList = "";
		try {
			newsList = jo.getObject("newsList", String.class);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("页面下载错误");
		}
		JSONObject jsonObject = JSONObject.parseObject(newsList);
		JSONArray jsonArray = jsonObject.getJSONObject("data").getJSONArray("posts");
		jsonObject = jsonArray.getJSONObject(jsonArray.size()-1);
		String nextUrl = jsonObject.getString("time");
		jo.put("nextUrl", nextUrl);
		return jsonArray;
	}

	@Override
	protected long getNewsTime(Object obj) throws Exception {
		// 转换对象为JSONObject
		JSONObject item = JSONObject.parseObject(obj.toString());
		String strPubDate = item.getString("time");
		return Long.valueOf(strPubDate);
	}

	@Override
	protected String getNewsDocUrl(String baseUrl, Object obj) {
		// 对象类型转换
		JSONObject item = JSONObject.parseObject(obj.toString());
		// 组装url
		String combineUrl = "http://www.qiuduoduo.cn/details/";
		return combineUrl + item.getString("id"); 
	}

	@Override
	protected String getNextUrl(String url, String nextUrl, int page) { 
		return url.replaceAll("b=\\d+", "b="+nextUrl);
	}

}
