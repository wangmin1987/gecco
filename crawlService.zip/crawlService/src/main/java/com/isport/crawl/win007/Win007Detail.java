package com.isport.crawl.win007;

import org.jsoup.nodes.Element;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.isport.Constants;
import com.isport.bean.NewsInfoBean;
import com.isport.crawl.AbstractDetailPipeLine;

@Service
public class Win007Detail extends AbstractDetailPipeLine {

	@Override
	protected void setParseParameter(NewsInfoBean newsInfoBean, JSONObject jo) throws Exception {
		// 获取标题
		String title = jo.getString("title");
		// 获取发布时间 格式：发表于 2018年12月09日 14:48
		String pubDate = jo.getString("pubDate");
		pubDate = pubDate.replace("发表于 ", "").replace("年", "-").replace("月", "-").replace("日", "");
		pubDate = pubDate.trim() + ":00";
		newsInfoBean.setTitle(title);
		newsInfoBean.setPub_date(pubDate);
	}

	@Override
	protected void setConstant(NewsInfoBean newsInfoBean) {
		newsInfoBean.setSource(Constants.NEWS_SOURCE_WIN007.value);
		newsInfoBean.setSource_icon(Constants.NEWS_ICON_WIN007.value);
	}

	@Override
	protected String getBodyExpession() {
		return "#contentData";
	}
	
	protected void parseCleanData(Element ele) {
		ele.select("p:last-child").remove();
	}

}
