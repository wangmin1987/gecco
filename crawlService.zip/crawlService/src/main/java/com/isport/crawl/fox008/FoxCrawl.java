package com.isport.crawl.fox008;

import org.springframework.stereotype.Service;

import com.geccocrawler.gecco.dynamic.DynamicGecco;

@Service
public class FoxCrawl {
	
	public void register() {
		Class<?> newsBriefs = DynamicGecco.html().stringField("docUrl").csspath("a").attr("href").build()
				.stringField("pubDate").csspath("span").text().build().register();
		
		DynamicGecco.html()
		.gecco(new String[] { "http://www.fox008.com/{channel}/","http://www.fox008.com/{channel}/2"}, "foxList")
		.requestField("request").request().build().listField("newsList", newsBriefs).csspath("div.news_left598 li").build()
		.stringField("nextUrl").csspath("div.pagelist a:contains[下一页]").attr("href").build().register();
	
		DynamicGecco.html().gecco(new String[] {"https://www.fox008.com/{channel}/{id}.html","http://www.fox008.com/{channel}/{id}.html"}, "foxDetail").requestField("request").request().build()
		.stringField("content").csspath("html").build()
		.stringField("title").csspath("h1 > font").text().build()
		.stringField("pubDate").csspath("div.news_times").text().build().register();
	}

}
