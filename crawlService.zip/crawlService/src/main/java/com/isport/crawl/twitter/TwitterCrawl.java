//package com.isport.crawl.twitter;
//
//import java.io.IOException;
//import java.util.Date;
//import java.util.List;
//
//import org.springframework.stereotype.Service;
//
//import twitter4j.Paging;
//import twitter4j.Status;
//import twitter4j.Twitter;
//import twitter4j.TwitterException;
//import twitter4j.TwitterFactory;
//import twitter4j.conf.ConfigurationBuilder;
//
///**
// * twitter 抓取
// * 
// * @author 八斗体育
// *
// */
//@Service
//public class TwitterCrawl {
//	
//	public static void main(String[] args) {
//		try {
//			TwitterCrawl tc = new TwitterCrawl();
//			tc.new GetUserTimeline().getUrlTimeline();
//		} catch (TwitterException | IOException e) {
//			e.printStackTrace();
//		}
//	}
//
//	public class GetConfiguration {
//		public Twitter getNewInstance() {
//			ConfigurationBuilder cb = new ConfigurationBuilder();
//			cb.setDebugEnabled(true).setOAuthConsumerKey("XQOBGSC66gqLulaEPNtJc****")
//					.setOAuthConsumerSecret("UsNDcBdllprdnP0qH41CaYMYgNZDZUoFq0Qhj78uGCn6a****")
//					.setOAuthAccessToken("4678138488-nhpI9HlnYQEH3MiWY87WgYKisMZnmB****Yhr3H")
//					.setOAuthAccessTokenSecret("6RPOWclehdb****U6rbcdmleLUsjxQ8wujA7WHZqOEkFs");
//			TwitterFactory tf = new TwitterFactory(cb.build());
//			Twitter twitter = tf.getInstance();
//			return twitter;
//		}
//
//	}
//
//	public class GetUserTimeline {
//		public void getUrlTimeline() throws TwitterException, IOException {
//			GetConfiguration conf = new GetConfiguration();
//			Twitter twitter = conf.getNewInstance();
//			List<Status> statuses;
//			String user = "BillGates";
//			Paging page = new Paging();
//			page.count(20);
//			statuses = twitter.getUserTimeline(user, page);
//			System.out.println("Showing@" + user + "'suser timeline.");
//			for (Status status : statuses) {
//				String content = status.getText(); // tweet内容
//				String ScreenName = status.getUser().getScreenName();
//				Date publishDate = status.getCreatedAt();
//				System.out.println("@" + ScreenName + "--" + content + "--" + publishDate);
//				String tweetUrl = "https://twitter.com/" + status.getUser().getScreenName() + "/status/"
//						+ status.getId();
//				System.out.println("tweetUrl:" + tweetUrl);
//				if (status.getMediaEntities() != null && status.getMediaEntities().length >= 1) {
//					try {
//						String type = status.getMediaEntities()[0].getType();
//						if (type.equals("photo")) {
//							String imgUrl = status.getMediaEntities()[0].getMediaURL();
//							System.out.println("imgUrl:" + imgUrl);
//						} else if (type.equals("video")) {
//							String videoUrl = status.getMediaEntities()[0].getMediaURL();
//							System.out.println("videoUrl:" + videoUrl);
//						} else {
//							String animatedGifUrl = status.getMediaEntities()[0].getMediaURL();
//							System.out.println("animatedGifUrl:" + animatedGifUrl);
//						}
//
//					} catch (Exception e) {
//						System.out.println("Status:" + status);
//						System.out.println(e.getStackTrace());
//					}
//
//					if (status.getRetweetedStatus() != null) {
//						String reScreenName = status.getRetweetedStatus().getUser().getScreenName();
//						Long RetweetedId = status.getRetweetedStatus().getId();
//
//						String retweetUrl = "https://twitter.com/" + reScreenName + "/status/" + RetweetedId;
//						System.out.println("retweetUrl:" + retweetUrl);
//					}
//				}
//			}
//		}
//	}
//}
