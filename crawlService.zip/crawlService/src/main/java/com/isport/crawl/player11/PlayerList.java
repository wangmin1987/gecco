package com.isport.crawl.player11;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.isport.crawl.AbstractListPipeLine;

@Service
public class PlayerList extends AbstractListPipeLine{

	private static final Logger LOGGER = LoggerFactory.getLogger(PlayerList.class);
	@Override
	protected Object getList(JSONObject jo) throws Exception {
		return jo.getJSONArray("newsList");
	}

	@Override
	protected long getNewsTime(Object obj) throws Exception {
		// TODO Auto-generated method stub
		JSONObject item = JSONObject.parseObject(obj.toString());
		 // 发布时间：2018-12-10 09:06
		String strPubDate = item.getString("pubDate");
		if(strPubDate.length() > 20) {
			strPubDate = strPubDate.substring(5, strPubDate.length());
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		try {
			return sdf.parse(strPubDate).getTime();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	
	@Override
	protected String getNewsDocUrl(String baseUrl, Object obj) {
		JSONObject item = JSONObject.parseObject(obj.toString());
		return "http://www.11player.com" + item.getString("docUrl");
	}

	@Override
	protected String getNextUrl(String url, String nextUrl, int page) {
		
		return String.format("http://www.11player.com/txzq/cp/zqjc/list_362_%s.html",page+"");
	}
	

}
