package com.isport.crawl.nowscore;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.isport.crawl.AbstractListPipeLine;

@Service
public class NowscoreList extends AbstractListPipeLine{

	private static final Logger LOGGER = LoggerFactory.getLogger(NowscoreList.class);
	@Override
	protected Object getList(JSONObject jo) throws Exception {
//		System.out.println(jo.toString());
		return jo.getJSONArray("newsList");
	}

	@Override
	protected long getNewsTime(Object obj) throws Exception {
		return 0;
	}
	
	
	@Override
	protected String getNewsDocUrl(String baseUrl, Object obj) {
		JSONObject item = JSONObject.parseObject(obj.toString());
		return "http://www.nowscore.com"+item.getString("docUrl");
	}

	@Override
	protected String getNextUrl(String url, String nextUrl, int page) {
		
		return String.format("http://www.nowscore.com/?page=%s",page+"");
	}

}
