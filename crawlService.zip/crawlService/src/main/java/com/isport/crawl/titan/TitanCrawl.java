package com.isport.crawl.titan;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.geccocrawler.gecco.dynamic.DynamicGecco;

/**
 * 体坛网
 * @author 八斗体育
 *
 */
@Service
public class TitanCrawl {
	public void register() {
		// 列表页 spiderBean
		DynamicGecco.json().requestField("request").request().build()
				// 匹配地址
				.gecco(new String[] { 
						"http://app.titan24.com/scrollnews/?channel={channel}&page={page}&json={json}" },
						"titanList")
				.field("newsList", JSONArray.class).jsonpath("$.datas").build().register();

		// 详情spiderBean
		DynamicGecco.html()
				.gecco(new String[] { "http://{channel}.titan24.com/{datetime}/{id}.html" }, "titanDetail")
				// 请求对象
				.requestField("request").request().build()
				// 网页内容
				.stringField("content").csspath("html").build()
				// 新闻标题
				.stringField("title").csspath("div.article-header h1").text().build() 
				// 发布日期
				.stringField("pubDate").csspath("div.article-info").text().build().register();

	}
}
