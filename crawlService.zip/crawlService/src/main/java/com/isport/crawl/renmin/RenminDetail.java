package com.isport.crawl.renmin;

import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.safety.Whitelist;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.geccocrawler.gecco.request.HttpRequest;
import com.isport.Constants;
import com.isport.bean.NewsInfoBean;
import com.isport.crawl.AbstractDetailPipeLine;
import com.isport.utils.CrawlDateUtil;

@Service
public class RenminDetail extends AbstractDetailPipeLine {
	private static final Logger LOGGER = LoggerFactory.getLogger(RenminDetail.class);
	// request 参数设置
	protected void setRequestParameters(HttpRequest request, NewsInfoBean newsInfoBean) {
		String indexUrl = request.getParameter("index_url");
		String tag = request.getParameter("tag");
		String authorId = request.getParameter("author_id");
		String channelId = request.getParameter("custom_channel_id");
		newsInfoBean.setIndex_url(indexUrl);
		newsInfoBean.setTag(tag);
		newsInfoBean.setAuthor_id(authorId);
		newsInfoBean.setChannel_id(channelId);
	}
	@Override
	protected void setParseParameter(NewsInfoBean newsInfoBean, JSONObject jo) throws Exception {
		// 获取标题
		String title = jo.getString("title");
		// 获取发布时间
		String pubDate = jo.getString("pubDate");
		if (!StringUtils.isEmpty(pubDate)) {
			int lyIndex = pubDate.indexOf("来源");
			pubDate = pubDate.substring(0, lyIndex);
			pubDate = pubDate.trim();
			pubDate = CrawlDateUtil.dateConvert5(pubDate);
			System.out.println(pubDate);
		} else {
			pubDate = jo.getString("pubDate2");
			int mhIndex = pubDate.indexOf("：");
			pubDate = pubDate.substring(mhIndex + 1, pubDate.length());
			pubDate = pubDate.trim();
			pubDate = CrawlDateUtil.dateConvert5(pubDate);
			System.out.println(pubDate);
		}
		newsInfoBean.setTitle(title);
		newsInfoBean.setPub_date(pubDate);
	}

	@Override
	protected void setConstant(NewsInfoBean newsInfoBean) {
		newsInfoBean.setSource(Constants.NEWS_SOURCE_RENMIN.value);
		newsInfoBean.setSource_icon(Constants.NEWS_ICON_RENMIN.value);
	}

	@Override
	protected String getBodyExpession() {
		return "#rwb_zw";
	}

	@Override
	protected boolean parseContent(NewsInfoBean newsInfoBean) throws Exception {

		String url = newsInfoBean.getUrl(), parent_url = newsInfoBean.getIndex_url();
		try {
			String html = newsInfoBean.getHtml();
			// 解析html
			Document doc = Jsoup.parse(html);
			// 获取body体标签
			Elements bodyDivs = doc.select("#rwb_zw");
			if (bodyDivs.size() == 0) {
//				throw new Exception("找不到正文区域，jsoup表达式有误：" + getBodyExpession());
				bodyDivs = doc.select("#picG");
				if (bodyDivs.size() == 0) {
					throw new Exception("找不到正文区域，jsoup表达式有误：" + getBodyExpession());
				}
			} 
			Element bodyDiv = bodyDivs.get(0);
			// 清洗目标内容区域内的无关数据
			parseCleanData(bodyDiv);
			// 修改内容区IMG标签的地址
			newsParseService.uploadImg(bodyDiv, url);
			// 删除A标签保留文本
			String cleanContent = Jsoup.clean(bodyDiv.html(), Whitelist.relaxed().removeTags("a"));
			if(cleanContent.contains("next_page.jpg")) {
				throw new Exception("含有下一页");
			}
			// infoBean属性设置：正文内容
			newsInfoBean.setContent(cleanContent);
			// infoBean属性设置：正文摘要
			newsInfoBean.setSummary(newsParseService.getSummary(cleanContent));
			// infoBean属性设置：资讯配图
			newsInfoBean.setTitle_imgs(newsParseService.getImage(bodyDiv));
			// 资讯非法内容过滤：1.正文内容过短；2.无配图的视频资讯
			newsParseService.filter(cleanContent);
			return true;
		} catch (Exception e) {
			String message = e.getMessage();
			newsInfoBean.setParse_error(message.length() < 255 ? message : message.substring(0, 254));
			LOGGER.error("parent_url:" + parent_url + ",url:" + url + " 内容解析错误：" + e.getMessage());
		}
		return false;

	}
}
