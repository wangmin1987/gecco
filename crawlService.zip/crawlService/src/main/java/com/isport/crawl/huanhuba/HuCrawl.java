package com.isport.crawl.huanhuba;
 
import org.springframework.stereotype.Service;
 
import com.geccocrawler.gecco.dynamic.DynamicGecco;

@Service
public class HuCrawl {
		 
		public void register() {
			Class<?> newsBriefs = DynamicGecco.html().stringField("docUrl").csspath("a").attr("href").build()
					.stringField("pubDate").csspath("span.time").text().build().register();
			
			DynamicGecco.html()
			.gecco(new String[] { "https://www.huanhuba.com/info/live/","https://www.huanhuba.com/info/live-{game}/"}, "huList")
			.requestField("request").request().build().listField("newsList", newsBriefs)
			.csspath("div.intelcell").build().stringField("nextUrl").csspath("ul.pageturn li.next >a").attr("href").build().register();
		
			DynamicGecco.html().gecco(new String[] {"https://www.huanhuba.com/info/{id}.html","http://www.huanhuba.com/info/{id}.html"}, "huDetail").requestField("request").request().build()
			.stringField("content").csspath("html").build()
			.stringField("title").csspath("div.main-content > h1").text().build()
			.stringField("pubDate").csspath("div.intell-description").text().build().register();
		}


}
