package com.isport.crawl.video;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isport.crawl.cctv.CctvvideoCrawl;
import com.isport.crawl.cctv.CslCrawl;
import com.isport.crawl.dianjinghu.CSGOvideoCrawl;
import com.isport.crawl.dianjinghu.LOLvideoCrawl;
import com.isport.crawl.dianjinghu.PUBGvideoCrawl;
import com.isport.crawl.dianjinghu.PVPvideoCrawl;
import com.isport.crawl.tengxun.video.FavideoCrawl;
import com.isport.crawl.tengxun.video.GBCrawl;
import com.isport.crawl.tengxun.video.GBCrawlv2;
import com.isport.crawl.tengxun.video.UefavideoCrawl;
import com.isport.crawl.tengxun.video.UefavideoCrawl2;
import com.isport.crawl.tengxun.video.ZcvideoCrawl;

/**
 * 视频抓取服务
 * 
 * @author 八斗体育
 *
 */
@Service
public class VideoService {

	@Autowired
	CctvvideoCrawl cctvvideoCrawl;

	@Autowired
	com.isport.crawl.aiyuke.video.PyVideoCrawl pyVideoCrawl;

	@Autowired
	com.isport.crawl.tengxun.video.ZcvideoCrawlv2 zcvideoCrawlv2;
	
	@Autowired
	ZcvideoCrawl zcvideoCrawl;

	@Autowired
	GBCrawlv2 gBCrawlv2;
	
	@Autowired
	GBCrawl gBCrawl;

	@Autowired
	com.isport.crawl.tengxun.video.FavideoCrawlv2 favideoCrawlv2;
	
	@Autowired
	FavideoCrawl favideoCrawl;
	@Autowired
	com.isport.crawl.tengxun.video.NbavideoCrawl nbavideoCrawl;

	@Autowired
	UefavideoCrawl2 uefavideoCrawl2;
	
	@Autowired
	UefavideoCrawl uefavideoCrawl;
	
	@Autowired
	LOLvideoCrawl lOLvideoCrawl;
	
	@Autowired
	PVPvideoCrawl pVPvideoCrawl;
	 
	@Autowired
	PUBGvideoCrawl pUBGvideoCrawl;
	
	@Autowired
	CSGOvideoCrawl cSGOvideoCrawl;
	
	@Autowired
	CslCrawl cslCrawl;
	
	@Autowired
	com.isport.crawl.cctv.ChampionsleagueCrawl championsleagueCrawl;
	
	@Autowired
	com.isport.crawl.cctv.PremierleagueCrawl premierleagueCrawl;
	
	@Autowired
	com.isport.crawl.cctv.SerieaCrawl serieaCrawl;
	
	public void crawllq() {
		try {
			nbavideoCrawl.crawl();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void crawlzq() {
		try {
			zcvideoCrawl.crawl();
		} catch (Exception e) {
			e.printStackTrace();
		}
		 
		try {
			uefavideoCrawl.crawl();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			favideoCrawl.crawl();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			gBCrawl.crawl();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void crawldj() {
		lOLvideoCrawl.crawl("");
		pVPvideoCrawl.crawl("");
		pUBGvideoCrawl.crawl("");
		cSGOvideoCrawl.crawl("");
	}
	
	
	public void crawlcctvfb() {
		try {
			championsleagueCrawl.crawl("http://sports.cctv.com/special/championsleague/videos/index.shtml");
		} catch (Exception e) {
			e.printStackTrace();
		} 
		try {
			cslCrawl.crawl("http://sports.cctv.com/csl/video/index.shtml");
		} catch (Exception e) {
			e.printStackTrace();
		} 
		try {
			premierleagueCrawl.crawl("http://sports.cctv.com/special/premierleague/videos/index.shtml");
		} catch (Exception e) {
			e.printStackTrace();
		} 
		try {
			serieaCrawl.crawl("http://sports.cctv.com/special/seriea/videos/");
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
}
