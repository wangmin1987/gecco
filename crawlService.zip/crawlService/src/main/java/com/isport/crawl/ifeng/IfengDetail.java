package com.isport.crawl.ifeng;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.safety.Whitelist;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.geccocrawler.gecco.request.HttpRequest;
import com.isport.Constants;
import com.isport.bean.NewsInfoBean;
import com.isport.crawl.AbstractDetailPipeLine;
import com.isport.utils.StringUtils;

@Service
public class IfengDetail extends AbstractDetailPipeLine {
	private static final Logger LOGGER = LoggerFactory.getLogger(IfengDetail.class);

	// request 参数设置
	protected void setRequestParameters(HttpRequest request, NewsInfoBean newsInfoBean) {
		String indexUrl = request.getParameter("index_url");
		String tag = request.getParameter("tag");
		String authorId = request.getParameter("author_id");
		String channelId = request.getParameter("custom_channel_id");
		newsInfoBean.setIndex_url(indexUrl);
		newsInfoBean.setTag(tag);
		newsInfoBean.setAuthor_id(authorId);
		newsInfoBean.setChannel_id(channelId);
	}

	@Override
	protected void setParseParameter(NewsInfoBean newsInfoBean, JSONObject jo) throws Exception {
		JSONObject item = jo.getJSONObject("newsList");
		// 获取标题
		String title = item.getString("title");
		// 获取发布时间
		String strPubDate = item.getString("newsTime");
		JSONObject contentData = item.getJSONObject("contentData");
		if (contentData == null) {
			throw new Exception("图片新闻");
		}
		JSONArray contentList = contentData.getJSONArray("contentList"); 
		StringBuilder sb = new StringBuilder();
		for (Object object : contentList) {  
			String content = object.toString();
			content =content.replace("\\\"", ""); 
			content =content.replace("{\"data\":\"","");
			content =content.replace("\",\"type\":\"text\"}", "");
			sb.append(content);
		}
		// 设置标题
		newsInfoBean.setTitle(title);
		// 设置抽取时间
		newsInfoBean.setPub_date(strPubDate);
		newsInfoBean.setContent(sb.toString());
	}
	
	public static void main(String[] args) {
		String test ="{\"data\":\"<p class=detailPic style=margin:0 auto;text-align:center><img alt=null src=http://d.ifengimg.com/q100/img1.ugc.ifeng.com/newugc/20181213/5/wemedia/c94a94d969a5aea91aab13ffcf72d3cb7290953b_size47_w953_h478.jpg style=height: 305px; /></p><p class=picIntro style=text-align:center;><span style=font-family: 楷体_gb2312,楷体; font-size:14px;>琼斯自摆乌龙</span></p><p>北京时间12月13日04:00，2018-19赛季欧冠H组收官战开打，曼联客场挑战瓦伦西亚。上半场，索勒尔率先破门，博格巴错失良机。下半场，菲尔-琼斯自摆乌龙，拉什福德替补进球扳回一城。最终，曼联在客场1-2不敌瓦伦西亚，以小组第二的身份晋级淘汰赛。</p><p>在上轮结束之后，曼联已经提前锁定一个晋级名额，但是没有确定的是第一还是第二。此役，费莱尼和弗雷德先发出战，博格巴重返曼联首发阵容。</p><p>比赛开始，第11分钟，瓦伦西亚防守时铲倒拉托，被主裁判黄牌警告，后者经过队医检查处理重新进行比赛。<strong>第17分钟，皮奇尼右路送出直塞，米纳插上得球横传禁区被挡出，索莱尔右侧得球一脚低射远角入网，1-0，瓦伦西亚主场领先曼联。</strong></p><p>第28分钟，拉托在右侧放倒了瓦伦西亚，吃到了一张黄牌。2分钟后，曼联开出右侧定位球到禁区，拜利门前争顶被吹冲撞门将犯规。第31分钟，皮奇尼右路起球传中，巴舒亚伊禁区里后点头球攻门高出横梁。第33分钟，瓦伦西亚左侧角球开到禁区，索莱尔后点小角度射门被罗梅罗扑出，孔多比亚右侧头球摆渡下来，随后又把球传到门前，迪亚卡比门前没能碰到皮球，皮球直接出了底线。</p><p>第35分钟，佩雷拉开出曼联右侧角球到禁区，费莱尼左侧头球攻门，无人防守的博格巴门前右侧起脚垫射，但是将球射偏。第44分钟，切里舍夫左侧送出横传，米纳倒地前分球，巴舒亚伊禁区前起脚远射偏出底线。</p><p>上半场结束，曼联客场0-1落后。</p><p>易边再战，曼联撤下罗霍，换上阿什利-杨。<strong>随后，索莱尔中路送出直塞，巴舒亚伊插上准备射门，菲尔-琼斯回追在弧顶处倒地解围，但是直接将球铲入自家大门，0-2，瓦伦西亚扩大领先。</strong></p><p>第58分钟，拉什福德替补登场，换下弗雷德。第63分钟，索莱尔前场右侧送出直塞，琼斯在解围时倒地，米纳单刀面对罗梅罗射门被挡出。第75分钟，瓦伦西亚分球，佩雷拉在前场右侧起脚远射，多梅内克侧身将球扑出底线。</p><p>第79分钟，卢卡库被林加德换下。第82分钟，拉什福德铲倒了韦佐，被主裁判黄牌警告。随后，博格巴左侧起脚兜射被多梅内克倒地扑出。<strong>第87分钟，林加德在左侧底线将球救回，阿什利-杨起脚传到门前，拉什福德头槌完成破门，1-2，曼联客场扳回一球。</strong></p><p>第88分钟，巴舒亚伊弧顶处起脚吊门稍稍偏出底线。随后曼联进攻再度来袭，博格巴左侧送出挑传，马塔禁区里转身射门没踢好，皮球偏出右侧底线。</p><p>最终，曼联在客场1-2不敌瓦伦西亚，以小组第二的身份晋级淘汰赛。</p><p>两队出场阵容：</p><p>瓦伦西亚：1-多梅内克、15-拉托（第52分钟，加雷）、12-迪亚卡比、3-韦佐、21-皮奇尼、11-切里舍夫（第67分钟，费兰-托雷斯）、10-帕雷霍、6-孔多比亚、8-索莱尔、22-米纳（第69分钟，罗德里戈）、23-巴舒亚伊</p><p>曼联：22-罗梅罗、16-罗霍（第47分钟，阿什利-杨）、4-菲尔-琼斯、3-拜利、25-安东尼奥-瓦伦西亚、6-博格巴、27-费莱尼、17-弗雷德（第58分钟，拉什福德）、15-佩雷拉、8-马塔、9-卢卡库（第79分钟，林加德）</p><p>（孤城）</p>\",\"type\":\"text\"}";
		test =test.replace("\\\"", ""); 
		test =test.replace("{\"data\":\"","");
		test =test.replace("\",\"type\":\"text\"}", "");
		System.out.println(test); 
	}
	@Override
	protected void setConstant(NewsInfoBean newsInfoBean) {
		newsInfoBean.setSource(Constants.NEWS_SOURCE_IFENG.value);
		newsInfoBean.setSource_icon(Constants.NEWS_ICON_IFENG.value);
	}

	@Override
	protected String getBodyExpession() {
		return "*";
	}

	@Override
	protected boolean parseContent(NewsInfoBean newsInfoBean) throws Exception {

		String url = newsInfoBean.getUrl(), parent_url = newsInfoBean.getIndex_url();
		try {
			String html = newsInfoBean.getContent();
			// 解析html
			Document doc = Jsoup.parse(html);
			// 获取body体标签
			Elements bodyDivs = doc.select(getBodyExpession());
			if (bodyDivs.size() == 0) {
				throw new Exception("找不到正文区域，jsoup表达式有误：" + getBodyExpession());
			}
			Element bodyDiv = bodyDivs.get(0);
			// 清洗目标内容区域内的无关数据
			parseCleanData(bodyDiv);
			// 修改内容区IMG标签的地址
			newsParseService.uploadImg(bodyDiv, url);
			// 删除A标签保留文本
			String cleanContent = Jsoup.clean(bodyDiv.html(), Whitelist.relaxed().removeTags("a"));
			// infoBean属性设置：正文内容
			newsInfoBean.setContent(cleanContent);
			// infoBean属性设置：正文摘要
			newsInfoBean.setSummary(newsParseService.getSummary(cleanContent));
			// infoBean属性设置：资讯配图
			newsInfoBean.setTitle_imgs(newsParseService.getImage(bodyDiv));
			// 资讯非法内容过滤：1.正文内容过短；2.无配图的视频资讯
			newsParseService.filter(cleanContent);
			return true;
		} catch (Exception e) {
			String message = e.getMessage();
			newsInfoBean.setParse_error(message.length() < 255 ? message : message.substring(0, 254));
			LOGGER.error("parent_url:" + parent_url + ",url:" + url + " 内容解析错误：" + StringUtils.getStackTrace(e));
		}
		return false;
	}
}
