package com.isport.crawl.qqty;

import org.springframework.stereotype.Service;

import com.geccocrawler.gecco.dynamic.DynamicGecco;

@Service
public class QqtyCrawl {
	
	public void register() {
		Class<?> newsBriefs = DynamicGecco.html().stringField("docUrl").csspath("a").attr("href").build()
				.stringField("pubDate").csspath("span.leftUser").text().build().register();
		
		DynamicGecco.html()
		.gecco(new String[] { "https://sporttery.qqty.com/jingcai/","https://sporttery.qqty.com/jingcai/?p={page}"}, "qqtyList")
		.requestField("request").request().build().listField("newsList", newsBriefs).csspath("div.expLiBox li").build()
		.stringField("nextUrl").csspath("ul.pagination li:last-child a").attr("href").build().register();
	
		DynamicGecco.html().gecco(new String[] {"https://sporttery.qqty.com/jingcai/{year}/{id}.html"}, "qqtyDetail").requestField("request").request().build()
		.stringField("content").csspath("html").build()
		.stringField("title").csspath("h1").text().build()
		.stringField("pubDate").csspath("div.long.testCss span:eq(0)").text().build().register();
	}

}
