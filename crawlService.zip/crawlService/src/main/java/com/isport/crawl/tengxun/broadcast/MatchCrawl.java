package com.isport.crawl.tengxun.broadcast;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;

import com.geccocrawler.gecco.downloader.DownloadException;
import com.geccocrawler.gecco.request.HttpGetRequest;
import com.geccocrawler.gecco.response.HttpResponse; 
import com.isport.service.impl.MatchCategoryInfoService;
import com.isport.service.impl.MatchDataInfoService;
import com.isport.service.impl.MatchInfoService;

/**
 * 赛程类
 * @author 八斗体育
 *
 */
public class MatchCrawl {

	@Autowired
	MatchInfoService matchInfoService;

	@Autowired
	MatchCategoryInfoService matchCategoryInfoService;
	
	@Autowired
	MatchDataInfoService matchDataInfoService;
	// 通道id
	@SuppressWarnings("serial")
	protected HashMap<String, String> channels = new HashMap<String, String>() {
		{
			put("篮球", "cbb9bffc02e040328e13a776c26da706");
			put("足球", "e5e4aa2ca8864c97a589b9d798a75eb6"); 
		}
	};
 
	protected String clean(String gson) {
		int khIndex = gson.indexOf("(");
		return gson.substring(khIndex + 1, gson.length() - 1);
	}

	protected String get(String url) {
		HttpClientDownLoader httpClientDownloader = new HttpClientDownLoader();
		HttpGetRequest request = new HttpGetRequest(url);
		int timeout = 1000 * 30;
		HttpResponse response = null;
		try {
			response = httpClientDownloader.download(request, timeout);
			return response.getContent();
		} catch (DownloadException e) {
			e.printStackTrace();
		}
		return null;
	}

}
