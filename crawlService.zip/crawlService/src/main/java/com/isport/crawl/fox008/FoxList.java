package com.isport.crawl.fox008;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.geccocrawler.gecco.request.HttpRequest;
import com.isport.crawl.AbstractListPipeLine;

@Service
public class FoxList extends AbstractListPipeLine{

	private static final Logger LOGGER = LoggerFactory.getLogger(FoxList.class);
	@Override
	protected Object getList(JSONObject jo) throws Exception {
		return jo.getJSONArray("newsList");
	}

	@Override
	protected long getNewsTime(Object obj) throws Exception {
		// TODO Auto-generated method stub
		JSONObject item = JSONObject.parseObject(obj.toString());
		
		String strPubDate = item.getString("pubDate");
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyyy hh:mm:ss aaa");
		try {
			return sdf.parse(strPubDate).getTime();
		} catch (ParseException e) {
			e.printStackTrace();
			LOGGER.error("日期格式化错误" + strPubDate);
		}
		return 0;
	}
	
//	@Override
//	protected void setRequestParameter(HttpRequest subRequest, Object obj) {
//		// 转换对象为JSONObject
//		JSONObject item = JSONObject.parseObject(obj.toString());
//		String strPubDate = item.getString("pubDate");
//		subRequest.addParameter("date", strPubDate);
//	}
	
	@Override
	protected String getNewsDocUrl(String baseUrl, Object obj) {
		JSONObject item = JSONObject.parseObject(obj.toString());
		return "http://www.fox008.com" + item.getString("docUrl");
	}

	@Override
	protected String getNextUrl(String url, String nextUrl, int page) {
		
		return url+page+"";
	}

}
