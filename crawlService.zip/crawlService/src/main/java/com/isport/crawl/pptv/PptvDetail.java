package com.isport.crawl.pptv;

import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.safety.Whitelist;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.geccocrawler.gecco.request.HttpRequest;
import com.isport.Constants;
import com.isport.bean.NewsInfoBean;
import com.isport.crawl.AbstractDetailPipeLine;
import com.isport.utils.OssUtils;
import com.isport.utils.StringUtils;

@Service
public class PptvDetail extends AbstractDetailPipeLine {
	@Autowired
	OssUtils ossUtils;
	private static final Logger LOGGER = LoggerFactory.getLogger(PptvDetail.class);

	// request 参数设置
	protected void setRequestParameters(HttpRequest request, NewsInfoBean newsInfoBean) {
		String indexUrl = request.getParameter("index_url");
		String tag = request.getParameter("tag");
		String authorId = request.getParameter("author_id");
		String channelId = request.getParameter("custom_channel_id");
		newsInfoBean.setIndex_url(indexUrl);
		newsInfoBean.setTag(tag);
		newsInfoBean.setAuthor_id(authorId);
		newsInfoBean.setChannel_id(channelId);
	}

	@Override
	protected void setParseParameter(NewsInfoBean newsInfoBean, JSONObject jo) throws Exception {
		newsInfoBean.setHtml(jo.toString());
		String newsDetail = jo.getObject("newsDetail", String.class);
		int index = newsDetail.indexOf("(");
		newsDetail = newsDetail.substring(index + 1, newsDetail.length() - 1);
		JSONObject obj = JSONObject.parseObject(newsDetail);
		obj = obj.getJSONObject("data").getJSONObject("contentBean");
		String title = obj.getString("title");
		String strPubDate = obj.getString("createTime");
		String content = obj.getString("content");
		String headerPic = obj.getString("cover");
		String filePath = ossUtils.uploadImage(headerPic);
		ArrayList<String> title_img = new ArrayList<String>();
		title_img.add(filePath);

		String url = "http://sports.pptv.com/article/pg_detail?aid=" + obj.getString("contentId") + "&type=article";
		// 详情页地址
		newsInfoBean.setUrl(url);
		// 设置标题
		newsInfoBean.setTitle(title);
		// 设置抽取时间
		newsInfoBean.setPub_date(strPubDate);
		// 网页内容
		newsInfoBean.setContent(content);
		newsInfoBean.setTitle_imgs(title_img);
	}

	@Override
	protected void setConstant(NewsInfoBean newsInfoBean) {
		newsInfoBean.setSource(Constants.NEWS_SOURCE_PPTV.value);
		newsInfoBean.setSource_icon(Constants.NEWS_ICON_PPTV.value);
	}

	@Override
	protected String getBodyExpession() {
		return "*";
	}

	@Override
	protected boolean parseContent(NewsInfoBean newsInfoBean) throws Exception {
		String url = newsInfoBean.getUrl(), parent_url = newsInfoBean.getIndex_url();
		try {
			String html = newsInfoBean.getContent();
			// 解析html
			Document doc = Jsoup.parse(html);
			// 获取body体标签
			Elements bodyDivs = doc.select(getBodyExpession());
			if (bodyDivs.size() == 0) {
				throw new Exception("找不到正文区域，jsoup表达式有误：" + getBodyExpession());
			}
			Element bodyDiv = bodyDivs.get(0);
			// 清洗目标内容区域内的无关数据
			parseCleanData(bodyDiv);
			// 修改内容区IMG标签的地址
			newsParseService.uploadImg(bodyDiv);
			// 删除A标签保留文本
			String cleanContent = Jsoup.clean(bodyDiv.html(), Whitelist.relaxed().removeTags("a"));
			cleanContent = cleanMemo(cleanContent);
			// infoBean属性设置：正文内容
			newsInfoBean.setContent(cleanContent);
			// infoBean属性设置：正文摘要
			newsInfoBean.setSummary(newsParseService.getSummary(cleanContent));
			// infoBean属性设置：资讯配图
			List<String> imgs = newsParseService.getImage(bodyDiv);
			if (imgs.size() > 0) {
				newsInfoBean.setTitle_imgs(imgs);
			}  
			// 资讯非法内容过滤：1.正文内容过短；2.无配图的视频资讯
			newsParseService.filter(cleanContent);
			if (cleanContent.contains("picUrl")) {
				return false;
			}
			return true;
		} catch (Exception e) {
			String message = e.getMessage();
			newsInfoBean.setParse_error(message.length() < 255 ? message : message.substring(0, 254));
			LOGGER.error("parent_url:" + parent_url + ",url:" + url + " 内容解析错误：" + StringUtils.getStackTrace(e));
		}
		return false;
	}

	private String cleanMemo(String cleanContent) {
		return cleanContent.replaceAll("\\[MEMO .*\\[/MEMO\\]", "");
	}

	public static void main(String[] args) {
		String validStr = "\\n<p>[MEMO url=\"http://v.img.pplive.cn/cp120/d9/e5/d9e5536dc5d34fd7957f31eb01c06169/1544757593384.jpg\"]29453227[/MEMO]【红军名宿双";
		String pattern = "\\[MEMO .*\\[/MEMO\\]";
		System.out.println(validStr.replaceAll(pattern, ""));
	}

}
