package com.isport.crawl.huanhuba;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.isport.Constants;
import com.isport.bean.NewsInfoBean;
import com.isport.crawl.AbstractDetailPipeLine;

@Service
public class HuDetail extends AbstractDetailPipeLine{

	@Override
	protected void setParseParameter(NewsInfoBean newsInfoBean, JSONObject jo) throws Exception {
		// 获取标题
				String title = jo.getString("title");
				// 获取发布时间
				String pubDate = jo.getString("pubDate");
				//获取关键字
				
				int pos1 =  pubDate.indexOf("在现场") + 4;
				pubDate = pubDate.substring(pos1, pubDate.length());
				
				newsInfoBean.setTitle(title);
				newsInfoBean.setPub_date(pubDate);
	}

	@Override
	protected void setConstant(NewsInfoBean newsInfoBean) {
		newsInfoBean.setSource(Constants.NEWS_SOURCE_Huhuanba.value);
		newsInfoBean.setSource_icon(Constants.NEWS_ICON_Huhuanba.value);
		
	}

	@Override
	protected String getBodyExpession() {
		return "div.inteldesc";
	}

}
