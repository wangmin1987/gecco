package com.isport.crawl.tengxun.broadcast;

import com.geccocrawler.gecco.request.HttpPostRequest;

public class HttpJsonPostRequest extends HttpPostRequest{
	/**
	 * 
	 */
	private static final long serialVersionUID = 6884173208704246070L;
	private String jsonFiled;
	
	public HttpJsonPostRequest() {
		super();
	}
	public HttpJsonPostRequest(String url) {
		super(url);
	}

	public String getJsonFiled() {
		return jsonFiled;
	}

	public void setJsonFiled(String jsonFiled) {
		this.jsonFiled = jsonFiled;
	} 
}
