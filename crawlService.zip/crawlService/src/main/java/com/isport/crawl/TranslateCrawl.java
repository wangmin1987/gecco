package com.isport.crawl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLEncoder;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

import org.apache.commons.io.FileUtils;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;

import com.alibaba.fastjson.JSONArray;
import com.google.common.io.Resources;

/**
 * 翻译接口
 * 
 * @author 八斗体育
 *
 */
@Service
public class TranslateCrawl {

	/**
	 * 英语 to 中文
	 * 
	 * @param en
	 * @return
	 */
	public String translateEn2Zh(final String en) {
		try {
			String tk = getTk(en, "429051.241553697"),
					url = "https://translate.google.cn/translate_a/single?client=webapp&sl=auto&tl=zh-CN&hl=zh-CN&dt=at&dt=bd&dt=ex&dt=ld&dt=md&dt=qca&dt=rw&dt=rm&dt=ss&dt=t&pc=1&source=btn&ssel=0&tsel=0&kc=18&tk="
							+ tk + "&q=" + URLEncoder.encode(en, "utf-8"),
					destFile = "translate", sourceFile = downloadFile(url, destFile),
					content = FileUtils.readFileToString(new File(sourceFile), "utf-8"), zh = parseContent(content);
			delete(sourceFile);
			return zh;
		} catch (Exception e) {
			e.printStackTrace();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		return null;
	}

	private void delete(String sourceFile) {
		File file = new File(sourceFile);
		if (file.exists()) {
			file.delete();
		}
	}

	/**
	 * 解析返回结果
	 * 
	 * @param content
	 * @return
	 */
	private String parseContent(String content) {
		JSONArray jsonArray = JSONArray.parseArray(content);
		jsonArray = jsonArray.getJSONArray(0);
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < jsonArray.size() - 1; i++) {
			JSONArray items = jsonArray.getJSONArray(i);
			sb.append(items.get(0));
		}
		return sb.toString();
	}

	public static void main(String[] args) {
		TranslateCrawl tc = new TranslateCrawl();
		try {
			String en = "Another one of those European nights at Anfield ", tk = tc.getTk(en, "429051.241553697"),
					url = "https://translate.google.cn/translate_a/single?client=webapp&sl=auto&tl=zh-CN&hl=zh-CN&dt=at&dt=bd&dt=ex&dt=ld&dt=md&dt=qca&dt=rw&dt=rm&dt=ss&dt=t&pc=1&source=btn&ssel=0&tsel=0&kc=18&tk="
							+ tk + "&q=" + URLEncoder.encode(en, "utf-8"),
					content = FileUtils.readFileToString(new File(tc.downloadFile(url, "d:")), "utf-8");
			JSONArray jsonArray = JSONArray.parseArray(content);
			jsonArray = jsonArray.getJSONArray(0);
			for (int i = 0; i < jsonArray.size() - 1; i++) {
				JSONArray items = jsonArray.getJSONArray(i);
				System.out.println(items.get(0));
			}
			System.out.println(jsonArray);
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	/**
	 * 计算TK
	 * 
	 * @param text
	 * @param tkk
	 * @return
	 */
	public String getTk(String text, String tkk) {
		ScriptEngineManager sem = new ScriptEngineManager();
		ScriptEngine se = sem.getEngineByName("js");
		try {
			URL url = Resources.getResource("tk.js");
			String script = FileUtils.readFileToString(new File(url.getPath()), "utf-8");
			se.eval(script);
			Invocable inv2 = (Invocable) se;
			String tk = (String) inv2.invokeFunction("tk", text, tkk);
			return tk;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 下载文件
	 * 
	 * @param src_file
	 * @param dest_file
	 * @return
	 * @throws Throwable
	 */
	public String downloadFile(String src_file, String dest_file) throws Throwable {
		String fileName = getFileName(src_file);
		int downloadTimeout = 1000 * 30;
		try (CloseableHttpClient httpclient = HttpClients.createDefault()) {
			HttpGet httpget = new HttpGet(src_file);
			httpget.setConfig(RequestConfig.custom() //
					.setConnectionRequestTimeout(downloadTimeout) //
					.setConnectTimeout(downloadTimeout) //
					.setSocketTimeout(downloadTimeout) //
					.build());
			try (CloseableHttpResponse response = httpclient.execute(httpget)) {
				org.apache.http.HttpEntity entity = response.getEntity();
				File desc = new File(dest_file + File.separator + fileName);
				File folder = desc.getParentFile();
				folder.mkdirs();
				try (InputStream is = entity.getContent(); //
						OutputStream os = new FileOutputStream(desc)) {
					StreamUtils.copy(is, os);
				}
			} catch (Throwable e) {
				throw new Throwable("文件下载失败......", e);
			}
		}
		return dest_file + File.separator + fileName;
	}

	private String getFileName(String src_file) {
		int equalChar = src_file.lastIndexOf("=");
		return src_file.substring(equalChar + 1, src_file.length());
	}
}
