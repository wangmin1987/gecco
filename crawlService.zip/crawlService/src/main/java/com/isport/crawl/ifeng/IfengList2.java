package com.isport.crawl.ifeng;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

@Service
public class IfengList2 extends IfengList {

	@Override
	protected Object getList(JSONObject jo) throws Exception {
		String newsList = jo.getObject("newsList", String.class);
		int khIndex = newsList.indexOf("(");
		newsList = newsList.substring(khIndex + 1, newsList.length() - 1);
		JSONObject obj = JSONObject.parseObject(newsList);
		JSONArray list = obj.getJSONObject("data").getJSONArray("newsstream");
		JSONObject item = JSONObject.parseObject(list.get(list.size() - 1).toString());
		String id = item.getString("id");
		long timestamp = 0;
		String strPubDate = item.getString("newsTime");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			// 日期字符串转换为时间戳
			timestamp = sdf.parse(strPubDate).getTime();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String nextUrl = "http://shankapi.ifeng.com/shanklist/_/getColumnInfo/_/default/" + id + "/" + timestamp
				+ "/20/11-35121-/getColumnInfoCallback?callback=getColumnInfoCallback";
		jo.put("nextUrl", nextUrl);
		return list;
	}

}
