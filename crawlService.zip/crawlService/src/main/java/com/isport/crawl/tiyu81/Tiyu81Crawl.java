package com.isport.crawl.tiyu81;

import org.springframework.stereotype.Service;

import com.geccocrawler.gecco.dynamic.DynamicGecco;

/**
 * 八一体育 http://www.81tiyu.com/down_list.aspx?id=17
 * 
 * @author 八斗体育
 *
 */
@Service
public class Tiyu81Crawl {
	 
	public void register() {
		Class<?> lisBriefs = DynamicGecco.html().stringField("docUrl").csspath("a").attr("href").build()
				.stringField("pubDate").csspath("span").text().build()
				.register();
		DynamicGecco.html().gecco(new String[] { "http://www.81tiyu.com/down_list.aspx?id={id}&page={p}" }, "tiyu81List")
				.requestField("request").request().build().listField("newsList", lisBriefs)
				.csspath("#ctl00_ContentPlaceHolder1_listData li").build().register();
		DynamicGecco.html()
				.gecco(new String[] { "http://www.81tiyu.com/detail.aspx?id={id}" }, "tiyu81Detail")
				.requestField("request").request().build()
				.stringField("content").csspath("html").build().stringField("title").csspath("#ctl00_ContentPlaceHolder1_newstitle").text().build()
				.stringField("pubDate").csspath("#ctl00_ContentPlaceHolder1_newsabout").text().build()
				.register();
	}

}
