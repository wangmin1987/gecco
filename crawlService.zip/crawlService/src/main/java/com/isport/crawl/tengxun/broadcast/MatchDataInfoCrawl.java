package com.isport.crawl.tengxun.broadcast;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.isport.bean.MatchDataInfo;
import com.isport.bean.MatchInfo;
import com.isport.utils.DateUtils;

/**
 * 
 * @author 八斗体育
 *         http://matchweb.sports.qq.com/kbs/matchStat?mid=1:1034638&callback=matchStatsCallback0
 *         http://matchweb.sports.qq.com/kbs/matchHistoryData?mid=5:1021622&callback=fetchMatchHistoryDataCallback
 */
@Service
public class MatchDataInfoCrawl extends MatchCrawl {

	@Autowired
	AdviceService adviceService;

	public void crawlFinished() {
		List<MatchInfo> matchInfos = matchInfoService.getAll("2");
		for (MatchInfo matchInfo : matchInfos) {
			try {
				final String matchStatus = matchInfo.getMatchStat();
				if (matchStatus.equals("2")) {
					finshed(matchInfo);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void crawlIn() {
		List<MatchInfo> matchInfos = matchInfoService.getAll("1");
		for (MatchInfo matchInfo : matchInfos) {
			try {
				final String matchStatus = matchInfo.getMatchStat();
				if (matchStatus.equals("1")) {
					finshed(matchInfo);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

	}

	private void finshed(MatchInfo matchInfo) {
		final String mid = matchInfo.getMid(), channelId = matchInfo.getChannelId(), id = matchInfo.getId();
		String url = "http://matchweb.sports.qq.com/kbs/matchStat?mid=" + mid + "&callback=matchStatsCallback0";
		String gson = get(url);
		List<MatchDataInfo> matchDataInfos = parse(clean(gson));
		url = "http://matchweb.sports.qq.com/kbs/matchHistoryData?mid=" + mid
				+ "&callback=fetchMatchHistoryDataCallback";
		gson = get(url);
		matchDataInfos.addAll(parse1(clean(gson)));
		for (MatchDataInfo matchDataInfo : matchDataInfos) {
			matchDataInfo.setId(UUID.randomUUID().toString());
			matchDataInfo.setDataSource(url);
			matchDataInfo.setMatchId(id);
			matchDataInfo.setUpdateDate(DateUtils.getStrYYYYMMDDHHmmss(new Date()));
			matchDataInfo.setMatchType(channels.get("篮球").equals(channelId) ? "1" : "0");
			matchDataInfoService.saveOrUpdate(matchDataInfo);
			if (matchInfo.getMatchStat().equals("1"))
				// 更新通知
				adviceService.advice(matchDataInfo);
		}

	}

	private List<MatchDataInfo> parse1(String json) {
		List<MatchDataInfo> matchDataInfos = new ArrayList<MatchDataInfo>();
		JSONObject jsonObject = JSONObject.parseObject(json);
		jsonObject = jsonObject.getJSONObject("data");

		// 近5次交锋
		JSONArray historyVs = jsonObject.getJSONArray("historyVs");
		if (historyVs != null) {
			MatchDataInfo historyVsDataInfo = new MatchDataInfo();
			historyVsDataInfo.setMatchData(historyVs.toString());
			historyVsDataInfo.setDataType("41");
			matchDataInfos.add(historyVsDataInfo);
		}
		// 近5场比赛
		JSONObject finishMatches = jsonObject.getJSONObject("finishMatches");
		if (finishMatches != null) {
			MatchDataInfo finishDataInfo = new MatchDataInfo();
			finishDataInfo.setMatchData(finishMatches.toString());
			finishDataInfo.setDataType("42");
			matchDataInfos.add(finishDataInfo);
		}
		return matchDataInfos;
	}

	private List<MatchDataInfo> parse(String json) {
		List<MatchDataInfo> matchDataInfos = new ArrayList<MatchDataInfo>();
		JSONObject jsonObject = JSONObject.parseObject(json);
		jsonObject = jsonObject.getJSONObject("data");

		// 技术分析
		JSONArray teamStats = jsonObject.getJSONArray("teamStats");
		if (teamStats != null) {
			MatchDataInfo teamStatsDataInfo = new MatchDataInfo();
			teamStatsDataInfo.setMatchData(teamStats.toString());
			teamStatsDataInfo.setDataType("1");
			matchDataInfos.add(teamStatsDataInfo);
		}
		// 本场概况
		JSONObject periodGoals = jsonObject.getJSONObject("periodGoals");
		if (periodGoals != null) {
			MatchDataInfo periodGoalsDataInfo = new MatchDataInfo();
			periodGoalsDataInfo.setMatchData(periodGoals.toString());
			periodGoalsDataInfo.setDataType("2");
			matchDataInfos.add(periodGoalsDataInfo);
		}
		// 技术统计
		JSONObject playerStats = jsonObject.getJSONObject("playerStats");
		if (playerStats != null) {
			MatchDataInfo playerStatsDataInfo = new MatchDataInfo();
			playerStatsDataInfo.setMatchData(playerStats.toString());
			playerStatsDataInfo.setDataType("3");
			matchDataInfos.add(playerStatsDataInfo);
		}
		return matchDataInfos;
	}
}
