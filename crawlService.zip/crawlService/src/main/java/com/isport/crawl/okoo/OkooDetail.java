package com.isport.crawl.okoo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.isport.Constants;
import com.isport.bean.NewsInfoBean;
import com.isport.crawl.AbstractDetailPipeLine;

@Service
public class OkooDetail extends AbstractDetailPipeLine{

	@Override
	protected void setParseParameter(NewsInfoBean newsInfoBean, JSONObject jo) throws Exception {
		// 获取标题
				String title = jo.getString("title");
				// 获取发布时间  比赛时间：2018-12-11 1:00 星期二 
				String pubDate = jo.getString("pubDate");
				try {
					if(pubDate.length()>21) {
						
						pubDate = pubDate.substring(5, 21).trim()+":00";
					}else {
						pubDate +=":00";
					}
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					Date date = sdf.parse(pubDate);
					pubDate =  sdf.format(date);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				newsInfoBean.setTitle(title);
				newsInfoBean.setPub_date(pubDate);
	}

	@Override
	protected void setConstant(NewsInfoBean newsInfoBean) {
		newsInfoBean.setSource(Constants.NEWS_SOURCE_Okoo.value);
		newsInfoBean.setSource_icon(Constants.NEWS_ICON_Okoo.value);
		
	}

	@Override
	protected String getBodyExpession() {
		return "div.newsDetail_txt";
	}

}
