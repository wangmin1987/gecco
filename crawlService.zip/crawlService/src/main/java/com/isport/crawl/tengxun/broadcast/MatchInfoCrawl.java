package com.isport.crawl.tengxun.broadcast;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.isport.bean.MatchCategoryInfo;
import com.isport.bean.MatchInfo;
import com.isport.utils.DateUtils;
import com.isport.utils.StringUtils;

/**
 * 赛程信息
 * http://matchweb.sports.qq.com/matchUnion/list?startTime=2018-12-01&endTime=2018-12-16&columnId=100000&index=3&callback=fetchScheduleListCallback100000
 * http://kbs.sports.qq.com/
 * 
 * @author 八斗体育
 *
 */
@Service
public class MatchInfoCrawl extends MatchCrawl {

	private final String orgName = "1136181221107650";
	private final String appName = "badousports";

	public void crawl(String channelId, String columnId) {
		String startTime = getTime(3), endTime = getTime(-3);
		String url = "http://matchweb.sports.qq.com/matchUnion/list?startTime=" + startTime + "&endTime=" + endTime
				+ "&columnId=" + columnId + "" + "&index=3&callback=fetchScheduleListCallback" + columnId;
		System.out.println("Request:" + url);
		String gson = get(url); // 请求网络
		System.out.println(gson);
		List<MatchInfo> matchInfoes = parse(clean(gson));
		System.out.println(matchInfoes.size());
		for (MatchInfo matchInfo : matchInfoes) {
			matchInfo.setChannelId(channelId);
			matchInfo.setColumnId(columnId);
			matchInfo.setDetailUrl(url);
			if (filter(matchInfo))
				matchInfoService.saveOrUpdate(matchInfo);
		}

	}

	public static void main(String[] args) {
		MatchInfoCrawl matchInfoCrawl = new MatchInfoCrawl();
		MatchInfo matchInfo = new MatchInfo();
		matchInfo.setLeftName("ae");
		matchInfo.setRightName("be");
		String groupId = matchInfoCrawl.getGroupId(matchInfo);
		System.out.println(groupId);
	}

	private class Group {
		private String groupname;
		private String desc;
		private boolean public_;
		private int maxusers;
		private boolean approval;
		private String owner;

		public String getGroupname() {
			return groupname;
		}

		public void setGroupname(String groupname) {
			this.groupname = groupname;
		}

		public String getDesc() {
			return desc;
		}

		public void setDesc(String desc) {
			this.desc = desc;
		}

		public boolean isPublic_() {
			return public_;
		}

		public void setPublic_(boolean public_) {
			this.public_ = public_;
		}

		public int getMaxusers() {
			return maxusers;
		}

		public void setMaxusers(int maxusers) {
			this.maxusers = maxusers;
		}

		public boolean isApproval() {
			return approval;
		}

		public void setApproval(boolean approval) {
			this.approval = approval;
		}

		public String getOwner() {
			return owner;
		}

		public void setOwner(String owner) {
			this.owner = owner;
		}

	}

	public String getGroupId(MatchInfo matchInfo) {
		String token = getToken();
		String url = "http://a1.easemob.com/" + orgName + "/" + appName + "/chatgroups",
				groupName = "badou-" + matchInfo.getLeftName() + "-" + matchInfo.getRightName(), desc = groupName,
				owner = "admin";
		boolean public_ = true, approval = true;
		int maxUsers = 2000;
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", "Bearer " + token);
		headers.put("Accept", "application/json");
		Group group = new Group();
		group.setGroupname(groupName);
		group.setDesc(desc);
		group.setPublic_(public_);
		group.setMaxusers(maxUsers);
		group.setApproval(approval);
//		group.setAllowinvites(allowinvites);
//		group.setMembers_only(members_only);

		group.setOwner(owner);
		String jsonFileds = new Gson().toJson(group);
		jsonFileds = jsonFileds.replace("public_", "public");
		String json = post(url, jsonFileds, headers, new HashMap<String, String>(), new HashMap<String, String>());
		JSONObject jsonObject = JSONObject.parseObject(json);
		return jsonObject.getJSONObject("data").getString("groupid");
	}

	private String getToken() {
		return "YWMtKKmSzgm6EemcGmk6krj5pQAAAAAAAAAAAAAAAAAAAAFz7bsgBPER6bY3FaEWlfflAgMAAAFn7wDzgwBPGgCBFPSZtBCFcg-D3wyBox8B1R7UKqMEBeIb58uMFdHfLw";
	}

	public void crawl() {
		List<MatchCategoryInfo> matchCategoryInfoes = matchCategoryInfoService.getCategoryInfo(channels.get("足球"));
		// index = 3 当前时间新闻 =6 小于当前时间新闻
		for (MatchCategoryInfo matchCategoryInfo : matchCategoryInfoes) {
			String channelId = matchCategoryInfo.getChannelId();

			if (channels.containsValue(channelId)) {
				String startTime = getTime(3), endTime = getTime(-3), columnId = matchCategoryInfo.getColumnId();
				String url = "http://matchweb.sports.qq.com/matchUnion/list?startTime=" + startTime + "&endTime="
						+ endTime + "&columnId=" + columnId + "" + "&index=3&callback=fetchScheduleListCallback"
						+ columnId;
				System.out.println("Request:" + url);
				String gson = get(url); // 请求网络
				List<MatchInfo> matchInfoes = parse(clean(gson));
				for (MatchInfo matchInfo : matchInfoes) {
					matchInfo.setChannelId(channelId);
					matchInfo.setColumnId(columnId);
					matchInfo.setDetailUrl(url);
					if (filter(matchInfo))
						matchInfoService.saveOrUpdate(matchInfo);
				}
			}
		}
	}

	private boolean filter(MatchInfo matchInfo) {
		String leftName = matchInfo.getLeftName(), rightName = matchInfo.getRightName();
		if (StringUtils.isNUll(leftName) || StringUtils.isNUll(rightName))
			return false;
		return true;
	}

	private List<MatchInfo> parse(String gson) {
		List<MatchInfo> matchInfoes = new ArrayList<MatchInfo>();
		JSONObject jsonObject = JSONObject.parseObject(gson);
		jsonObject = jsonObject.getJSONObject("data");
		for (int i = 3; i >= -3; i--) {
			String matchsJson = jsonObject.getString(getTime(i));

			if (StringUtils.isNUll(matchsJson))
				continue;
			JSONArray matchsArray = JSONArray.parseArray(matchsJson);
			for (Object obj : matchsArray) {
				JSONObject match = JSONObject.parseObject(obj.toString());
				MatchInfo matchInfo = new MatchInfo();
				matchInfo.setId(UUID.randomUUID().toString());
				matchInfo.setCategoryId(match.getString("categoryId"));
				matchInfo.setCreateTime(DateUtils.getStrYYYYMMDDHHmmss(new Date()));
				matchInfo.setLeftBadge(match.getString("leftBadge"));
				matchInfo.setLeftGoal(match.getString("leftGoal"));
				matchInfo.setLeftId(match.getString("leftId"));
				matchInfo.setLeftName(match.getString("leftName"));
				matchInfo.setMatchDesc(match.getString("matchDesc"));
				matchInfo.setMatchStat(match.getString("livePeriod")); // livePeriod: { PRE: "0", IN: "1",END: "2"}
				matchInfo.setMatchType(match.getString("matchType"));
				matchInfo.setMid(match.getString("mid"));
				matchInfo.setRightBadge(match.getString("rightBadge"));
				matchInfo.setRightGoal(match.getString("rightGoal"));
				matchInfo.setRightId(match.getString("rightId"));
				matchInfo.setRightName(match.getString("rightName"));
				matchInfo.setStartDate(match.getString("startTime"));
				matchInfo.setUpdateTime(DateUtils.getStrYYYYMMDDHHmmss(new Date()));
				matchInfo.setvUrl(match.getString("VURL"));
				matchInfoes.add(matchInfo);
			}
		}
		return matchInfoes;
	}

	private String getTime(int i) {
		return DateUtils.getbeforeDay(i, "yyyy-MM-dd");
	}
}
