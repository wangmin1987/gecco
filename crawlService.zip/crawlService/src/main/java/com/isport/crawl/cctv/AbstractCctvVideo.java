package com.isport.crawl.cctv;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import com.isport.Constants;
import com.isport.bean.NewsInfoBean;
import com.isport.crawl.selenium.AbstractDriver;
import com.isport.crawl.video.Duplicate;
import com.isport.utils.DateUtils;
import com.isport.utils.StringUtils;

/**
 * 抽象
 * 
 * @author 八斗体育
 *
 */
public class AbstractCctvVideo extends AbstractDriver {

	@Autowired
	protected Duplicate duplicate;

	/**
	 * 设置默认发布时间
	 * 
	 * @param newsInfoBean
	 */
	protected void setDefaultPubDate(NewsInfoBean newsInfoBean) { 
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		String pubDate = newsInfoBean.getPub_date();
		if (StringUtils.isNUll(pubDate)) { 
			newsInfoBean.setPub_date(sdf.format(new Date()));
		} else { 
			long cur = new Date().getTime();
			long pubDateTime;
			try {
				pubDateTime = sdf.parse(pubDate).getTime();
				if (cur < pubDateTime) {
					newsInfoBean.setPub_date(sdf.format(new Date()));
				}
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 是否是合法数据，是否入库判断
	 * 
	 * @param newsInfoBean
	 * @return
	 */
	protected boolean isNUll(NewsInfoBean newsInfoBean) {
		String title = newsInfoBean.getTitle(), vedioUrl = newsInfoBean.getVideo_url();
		return StringUtils.isNUll(title) || StringUtils.isNUll(vedioUrl);
	}

	/**
	 * 设置视频常量
	 * 
	 * @param newsInfoBean
	 */
	protected void setConstant(NewsInfoBean newsInfoBean) {
		newsInfoBean.setSource(Constants.NEWS_SOURCE_CCTV.value);
		newsInfoBean.setSource_icon(Constants.NEWS_ICON_CCTV.value);
		String authorId = "080a700e28a84ace9d3a7732ffa39151", channelId = "0a309fa2948e46bba3d742e3397eb649";
		newsInfoBean.setAuthor_id(authorId);
		newsInfoBean.setChannel_id(channelId);
	}
}
