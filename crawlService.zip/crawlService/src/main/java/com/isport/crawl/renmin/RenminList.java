package com.isport.crawl.renmin;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.gargoylesoftware.htmlunit.util.UrlUtils;
import com.isport.crawl.AbstractListPipeLine;

@Service
public class RenminList extends AbstractListPipeLine {

	@Override
	protected Object getList(JSONObject jo) throws Exception {
		return jo.getJSONArray("newsList");
	}

	@Override
	protected long getNewsTime(Object obj) throws Exception {  
		return 0;
	}

	@Override
	protected String getNewsDocUrl(String baseUrl, Object obj) {
		JSONObject item = JSONObject.parseObject(obj.toString());
		return UrlUtils.resolveUrl(baseUrl, item.getString("docUrl"));
	}

	@Override
	protected String getNextUrl(String url, String nextUrl, int page) {
		return url.replaceAll("index//d+", "index"+page);
	}
	
}
