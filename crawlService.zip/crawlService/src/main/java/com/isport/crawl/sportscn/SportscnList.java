package com.isport.crawl.sportscn;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.gargoylesoftware.htmlunit.util.UrlUtils;
import com.isport.crawl.AbstractListPipeLine;

@Service
public class SportscnList extends AbstractListPipeLine {
	@Override
	protected Object getList(JSONObject jo) throws Exception {
		return jo.getJSONArray("newsList");
	}

	@Override
	protected long getNewsTime(Object obj) throws Exception {
		JSONObject item = JSONObject.parseObject(obj.toString());
		// 日期格式化 (08/15 09:42)
		String strPubDate = item.getString("pubDate"); 
		if (strPubDate == null) {
			throw new Exception("空串");
		}
		strPubDate = strPubDate.trim();
		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd");
		try {
			return sdf.parse(strPubDate).getTime();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	protected String getNewsDocUrl(String baseUrl, Object obj) {
		JSONObject item = JSONObject.parseObject(obj.toString());
		String docUrl = UrlUtils.resolveUrl(baseUrl, item.getString("docUrl")); 
		return docUrl;
	}

	@Override
	protected String getNextUrl(String url, String nextUrl, int page) {
		int lastIndex = url.lastIndexOf(".");
		return url.substring(0, lastIndex)+"html-page-"+page+".html";
	}
}
