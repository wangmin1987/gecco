package com.isport.crawl.renmin;

import org.springframework.stereotype.Service;

import com.geccocrawler.gecco.dynamic.DynamicGecco;

/**
 * 人民网 http://sports.people.com.cn/GB/22134/index.html
 * 
 * @author 八斗体育
 *
 */
@Service
public class RenminCrawl {

	public void register() {
		Class<?> lisBriefs = DynamicGecco.html().stringField("docUrl").csspath("strong a").attr("href").build()
				.register();
		DynamicGecco.html().gecco(new String[] { "http://sports.people.com.cn/GB/{id}/index{page}.html" }, "renminList")
				.requestField("request").request().build().listField("newsList", lisBriefs).csspath("div.hdNews.clearfix")
				.build().register(); 
		DynamicGecco.html().gecco(new String[] { "http://sports.people.com.cn/n1/{year}/{monthday}/{id}.html" }, "renminDetail")
				.requestField("request").request().build().stringField("content").csspath("html").build()
				.stringField("title").csspath("div.clearfix h1").text().build()
				.stringField("pubDate").csspath("div.box01 div.fl").text().build()
				.stringField("pubDate2").csspath("div.clearfix h2").text().build()
				.register();
	}

}
