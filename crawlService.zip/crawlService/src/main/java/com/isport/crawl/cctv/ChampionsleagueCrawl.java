package com.isport.crawl.cctv;

import org.springframework.stereotype.Service;

/**
 * 央视欧冠 http://sports.cctv.com/special/championsleague/videos/index.shtml
 * @author 八斗体育
 *
 */
@Service
public class ChampionsleagueCrawl extends SerieaCrawl{
	
}
