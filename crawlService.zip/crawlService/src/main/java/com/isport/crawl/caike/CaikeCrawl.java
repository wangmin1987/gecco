package com.isport.crawl.caike;

import org.springframework.stereotype.Service;

import com.geccocrawler.gecco.dynamic.DynamicGecco;

@Service
public class CaikeCrawl {
	
	public void register() {
		Class<?> newsBriefs = DynamicGecco.html().stringField("docUrl").csspath("a:eq(1)").attr("href").build()
				.stringField("pubDate").csspath("span.u2").text().build().register();
		
		DynamicGecco.html()
		.gecco(new String[] { "http://www.310win.com/jingcaizuqiu/info_t1sub2page{page}.html"}, "caikeList")
		.requestField("request").request().build().listField("newsList", newsBriefs).csspath("div.td_div3 table tr").build()
		.stringField("nextUrl").csspath("ul.pagination li:last-child a").attr("href").build().register();
	
		DynamicGecco.html().gecco(new String[] {"http://www.310win.com/jingcaizuqiu/info_{id}.html"}, "caikeDetail").requestField("request").request().build()
		.stringField("content").csspath("html").build()
		.stringField("title").csspath("div.articleTitle").text().build()
		.stringField("pubDate").csspath("div.aInfo").text().build().register();
	}

}
