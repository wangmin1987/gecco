package com.isport.crawl.win007;

import org.springframework.stereotype.Service;

import com.geccocrawler.gecco.dynamic.DynamicGecco;

@Service
public class Win007Crawl {
	
	public void register() {
		Class<?> newsBriefs = DynamicGecco.html().stringField("docUrl").csspath("a").attr("href").build()
				.stringField("pubDate").csspath("div.info").text().build().register();
		
		DynamicGecco.html()
		.gecco(new String[] { "http://news.win007.com/NewsContent.aspx?page={page}&newsType=2097&from={from}"}, "win007List")
		.requestField("request").request().build().listField("newsList", newsBriefs).csspath("li").build()
		.stringField("nextUrl").csspath("ul.pagination li:last-child a").attr("href").build().register();
	
		DynamicGecco.html().gecco(new String[] {"http://ba2.win007.com/2097/{id}.html"}, "win007Detail").requestField("request").request().build()
		.stringField("content").csspath("html").build()
		.stringField("title").csspath("div.qiuba_title span").text().build()
		.stringField("pubDate").csspath("div.qiuba_Info2").text().build().register();
	}

}
