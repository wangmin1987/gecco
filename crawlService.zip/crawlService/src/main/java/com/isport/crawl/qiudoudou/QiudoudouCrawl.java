package com.isport.crawl.qiudoudou;

import java.text.SimpleDateFormat;
import java.util.Date;
import org.springframework.stereotype.Service;
import com.geccocrawler.gecco.dynamic.DynamicGecco;

@Service
public class QiudoudouCrawl {
	public void register() { // 列表页spiderBean
		DynamicGecco.json().gecco(new String[] { "http://www.qiuduoduo.cn/api/posts?b={datetime}&ps={ps}&t={t}" }, "qiudoudouList")
				// 请求对象
				.requestField("request").request().build().field("newsList", String.class).renderName("qiudoudou")
				.build().register();
		
		// 详情spiderBean
		DynamicGecco.html().gecco("http://www.qiuduoduo.cn/details/{id}", "qiudoudouDetail")
				// 定义请求对象
				.requestField("request").request().build().stringField("content").csspath("html").build()
				// 定义标题
				.stringField("title").csspath("h1.art_title").text().build()
				// 定义发布日期
				.stringField("pubDate").csspath("span.time").text().build().register();
	}

	public static void main(String[] args) {
		System.out.println(new Date().getTime());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println(sdf.format(new Date(1544007495877L)));
		System.out.println(sdf.format(new Date(1543573000000L)));
		System.out.println(sdf.format(new Date(1543588153000L)));
		System.out.println(sdf.format(new Date(1543630506000L))); 
	}
}
