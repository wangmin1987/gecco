package com.isport.crawl.zgzcw;

import org.springframework.stereotype.Service;

import com.geccocrawler.gecco.dynamic.DynamicGecco;

@Service
public class ZgzcwCrawl {
	
	public void register() {
		Class<?> newsBriefs = DynamicGecco.html().stringField("docUrl").csspath("div.list-one-bt a").attr("href").build()
				.stringField("pubDate").csspath("p.pre-news-date").text().build().register();
		
		DynamicGecco.html()
		.gecco(new String[] { "http://news.zgzcw.com/jczq/list.shtml","http://news.zgzcw.com/jczq/list_{page}.shtml"}, "zgzcwList")
		.requestField("request").request().build().listField("newsList", newsBriefs).csspath("div.list-main li").build()
		.stringField("nextUrl").csspath("div.Page a:contains('下一页')").attr("href").build().register();
	
		DynamicGecco.html().gecco(new String[] {"http://news.zgzcw.com/jczq/zx_{id}.shtml"}, "zgzcwDetail").requestField("request").request().build()
		.stringField("content").csspath("html").build()
		.stringField("title").csspath("h1").text().build()
		.stringField("pubDate").csspath("div.cont-bt-ly span:eq(0)").text().build().register();
	}

}
