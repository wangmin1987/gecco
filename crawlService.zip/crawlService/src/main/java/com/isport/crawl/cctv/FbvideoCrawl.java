package com.isport.crawl.cctv;
 

import org.springframework.stereotype.Service;

import com.isport.Constants;
import com.isport.bean.NewsInfoBean; 

/**
 * 足球视频爬虫
 * 
 * @author 八斗体育
 *
 */
@Service
public class FbvideoCrawl extends CctvvideoCrawl {

	@Override
	protected void setRequestParameters(NewsInfoBean newsInfoBean) {
		String tag = "足球 视频";
		String title = newsInfoBean.getTitle();
		int start = title.indexOf("[");
		int end = title.indexOf("]");
		if (start > -1 && end > -1) {
			String sign = title.substring(start + 1, end);
			tag = tag + " " + sign;
		}
		newsInfoBean.setTag(tag);
	}

	@Override
	protected void process(NewsInfoBean newsInfoBean) {
		String keywords = newsInfoBean.getKey_word();
		keywords = keywords.replace("网球", "足球");
		newsInfoBean.setKey_word(keywords); 
		super.process(newsInfoBean);

	}

	/**
	 * 设置视频常量
	 * 
	 * @param newsInfoBean
	 */
	protected void setConstant(NewsInfoBean newsInfoBean) {
		newsInfoBean.setSource(Constants.NEWS_SOURCE_CCTV.value);
		newsInfoBean.setSource_icon(Constants.NEWS_ICON_CCTV.value);
		String authorId = "080a700e28a84ace9d3a7732ffa39151", channelId = "e5e4aa2ca8864c97a589b9d798a75eb6";
		newsInfoBean.setAuthor_id(authorId);
		newsInfoBean.setChannel_id(channelId);
	}
}
