package com.isport.crawl.win007;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.isport.crawl.AbstractListPipeLine;
import com.isport.crawl.okoo.OkooList;

@Service
public class Win007List extends AbstractListPipeLine{

	private static final Logger LOGGER = LoggerFactory.getLogger(OkooList.class);
	@Override
	protected Object getList(JSONObject jo) throws Exception {
		System.out.println(jo.toString());
		return jo.getJSONArray("newsList");
	}

	@Override
	protected long getNewsTime(Object obj) throws Exception {
		// TODO Auto-generated method stub
		JSONObject item = JSONObject.parseObject(obj.toString());
		//格式:1小时前  昨天16:29  30分钟前
		try {
			
			String strPubDate = item.getString("pubDate");
			long nowL = System.currentTimeMillis();
			if(strPubDate.indexOf("刚刚")>-1) {
				nowL = System.currentTimeMillis();
			}else if(strPubDate.indexOf("小时前")>-1) {
				strPubDate = strPubDate.replace("小时前 发表于", "");
				int beforeHour = Integer.parseInt(strPubDate);
				nowL = getBeforeHour(beforeHour);
			}else if(strPubDate.indexOf("分钟前")>-1) {
				strPubDate = strPubDate.replace("分钟前 发表于", "");
				int beforeMinute = Integer.parseInt(strPubDate);
				nowL = getBeforeMinute(beforeMinute);
			}else if(strPubDate.indexOf("昨天")>-1) {
				strPubDate = strPubDate.replace("昨天", "").replace(" 发表于", "").trim();
				nowL = getBeforeDay(1,strPubDate);
			}else if(strPubDate.contains("-")) {
				strPubDate = strPubDate.replace(" 发表于", "");
				nowL = formatDate(strPubDate);
			}
			
			return nowL;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	
	private long formatDate(String strPubDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd HH:mm");
		try {
			return sdf.parse(strPubDate).getTime();
		} catch (ParseException e) {
			e.printStackTrace();
			LOGGER.error("日期格式化错误" + strPubDate);
		}
		return 0;
	}

	@Override
	protected String getNewsDocUrl(String baseUrl, Object obj) {
		JSONObject item = JSONObject.parseObject(obj.toString());
		return item.getString("docUrl");
	}

	@Override
	protected String getNextUrl(String url, String nextUrl, int page) {
		// 2,3,4  1,1,2  1,2,0
		
		int iPage = (page-1) / 3 + 1;
		int iFrom = (page - 1) % 3;
		return String.format("http://news.win007.com/NewsContent.aspx?page=%s&newsType=2097&from=%s",iPage+"",iFrom+"");
	}
	
	private long getBeforeHour(int before) {
		Calendar instance = Calendar.getInstance();
		instance.add(Calendar.HOUR_OF_DAY, before*-1);
		return instance.getTimeInMillis() ;
	}
	private long getBeforeMinute(int before) {
		Calendar instance = Calendar.getInstance();
		instance.add(Calendar.MINUTE, before*-1);
		return instance.getTimeInMillis();
	}
	private long getBeforeDay(int before,String hourMinute) {
		try {
			Calendar instance = Calendar.getInstance();
			instance.add(Calendar.DAY_OF_MONTH, -1);
			String[] hourMinutes = hourMinute.split(":");
			instance.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hourMinutes[0]));
			instance.set(Calendar.MINUTE, Integer.parseInt(hourMinutes[1]));
			return instance.getTimeInMillis() ;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

}
