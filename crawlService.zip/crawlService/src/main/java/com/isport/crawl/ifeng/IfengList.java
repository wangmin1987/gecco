package com.isport.crawl.ifeng;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.isport.crawl.AbstractListPipeLine;

@Service
public class IfengList extends AbstractListPipeLine {

	@Override
	protected Object getList(JSONObject jo) throws Exception { 
		@SuppressWarnings("unchecked")
		List<Object> list = jo.getObject("newsList", List.class);
		JSONObject item = JSONObject.parseObject(list.get(list.size() - 1).toString());
		String id = item.getString("id");
		long timestamp = 0;
		String strPubDate = item.getString("newsTime");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			// 日期字符串转换为时间戳
			timestamp = sdf.parse(strPubDate).getTime();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String nextUrl = "http://shankapi.ifeng.com/shanklist/_/getColumnInfo/_/default/" + id + "/" + timestamp
				+ "/20/11-35121-/getColumnInfoCallback?callback=getColumnInfoCallback"; 
		jo.put("nextUrl", nextUrl);
		return jo.getObject("newsList", List.class);
	}

	@Override
	protected long getNewsTime(Object obj) throws Exception {
		// 转换对象为JSONObject
		JSONObject item = JSONObject.parseObject(obj.toString());
		String strPubDate = item.getString("newsTime");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			// 日期字符串转换为时间戳
			return sdf.parse(strPubDate).getTime();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return 0;

	}

	@Override
	protected String getNewsDocUrl(String baseUrl, Object obj) {
		// 对象类型转换
		JSONObject item = JSONObject.parseObject(obj.toString());
		return item.getString("url");
	}

	@Override
	protected String getNextUrl(String url, String nextUrl, int page) {
		return nextUrl;
	}

}
