package com.isport.crawl.eastday;

import org.springframework.stereotype.Service;

import com.geccocrawler.gecco.dynamic.DynamicGecco;

@Service
public class EastdayCrawl {

	public void register() {
		// 列表页 spiderBean
		DynamicGecco.json().requestField("request").request().build()
				// 匹配地址
				.gecco(new String[] {
						"https://sports.eastday.com/data/index/{js}.js?&callback=callback" },
						"eastdayList")
				.field("newsList", String.class).renderName("eastdayRender").build().register();
		
		Class<?> keyword = DynamicGecco.html().stringField("keyword").csspath("a").text().build().register();
		// 详情spiderBean
		DynamicGecco.html().gecco(new String[] {
				"https://sports.eastday.com/a/{id}.html" },
				"eastdayDetail")
				// 请求对象
		// 请求对象
		.requestField("request").request().build()
		// 网页内容
		.stringField("content").csspath("html").build()
		// 新闻标题
		.stringField("title").csspath("h1.tit").text().build()
		.listField("keywords", keyword).csspath("div.links span").build()
		// 发布日期
		.stringField("pubDate").csspath("p.fl").text().build().register();

	}
}
