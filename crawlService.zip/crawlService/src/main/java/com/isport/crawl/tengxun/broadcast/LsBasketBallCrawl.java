package com.isport.crawl.tengxun.broadcast;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.isport.bean.MatchDataInfo;
import com.isport.bean.MatchInfo;
import com.isport.utils.DateUtils;

@Service
public class LsBasketBallCrawl extends LsCrawl {

	@Override
	public void crawl(MatchInfo matchInfo) {
		String url = "https://www.leisu.com/";
		final String html = get(url);
		System.out.println("Request:" + url);
		final String id = matchInfo.getId();
		List<MatchBean> matchBeans = parse(html, matchInfo);
		for (MatchBean matchBean : matchBeans) {
			String detailHtml = get(matchBean.getDetail());
			System.out.println("Request:" + matchBean.getDetail());
			JSONObject jsonObject = JSONObject.parseObject(detailHtml);
			JSONArray jsonArray = jsonObject.getJSONObject("data").getJSONArray("tlive");
			MatchDataInfo matchDataInfo = new MatchDataInfo();
			matchDataInfo.setMatchData(jsonArray.toString());
			matchDataInfo.setDataType("0");
			matchDataInfo.setId(UUID.randomUUID().toString());
			matchDataInfo.setDataSource(matchBean.getDetail());
			matchDataInfo.setMatchId(id);
			matchDataInfo.setUpdateDate(DateUtils.getStrYYYYMMDDHHmmss(new Date()));
			matchDataInfo.setMatchType("1");
			// 更新通知
			adviceService.advice(matchDataInfo);
			matchDataInfoService.saveOrUpdate(matchDataInfo);
		}
	}

	@Override
	public List<MatchBean> parse(String html, MatchInfo matchInfo) {
		Document document = Jsoup.parse(html);
		Elements elements = document.select("div.children.live table.table.times-lot").select("tr");
		List<MatchBean> matchBeans = new ArrayList<MatchBean>();
		for (Element element : elements) {
			MatchBean matchBean = new MatchBean();
			String startTime = element.select("td.time").text();
			String home = element.select("td.home div span").text();
			String away = element.select("td.away div span").text();
			String sid = element.attr("data-id"); 
			matchBean.setStartTime(startTime);
			matchBean.setHome(home);
			matchBean.setAway(away);
			if (compare(matchBean, matchInfo)) {
//			if(home.equals("泽维卡平联")) {
				String detail = "http://api.leisu.com/basketball/live/matchdetail?sid=" + sid;
				matchBean.setDetail(detail);
				matchBeans.add(matchBean);
			}
		}
		return matchBeans;
	}

	@Override
	public void crawl(List<MatchInfo> matchInfoes) {
		System.out.println(matchInfoes.size());
		String url = "https://www.leisu.com/";
		final String html = get(url);
		System.out.println("Request:" + url);
		for (MatchInfo matchInfo : matchInfoes) { 
			final String id = matchInfo.getId(); 
			List<MatchBean> matchBeans = parse(html, matchInfo);
			for (MatchBean matchBean : matchBeans) {
				String detailHtml = get(matchBean.getDetail());
				System.out.println("Request:" + matchBean.getDetail());
				JSONObject jsonObject = JSONObject.parseObject(detailHtml);
				JSONArray jsonArray = jsonObject.getJSONObject("data").getJSONArray("tlive");
				MatchDataInfo matchDataInfo = new MatchDataInfo();
				matchDataInfo.setMatchData(jsonArray.toString());
				matchDataInfo.setDataType("0");
				matchDataInfo.setId(UUID.randomUUID().toString());
				matchDataInfo.setDataSource(matchBean.getDetail());
				matchDataInfo.setMatchId(id);
				matchDataInfo.setUpdateDate(DateUtils.getStrYYYYMMDDHHmmss(new Date()));
				matchDataInfo.setMatchType("1");
				// 更新通知
				adviceService.advice(matchDataInfo);
				matchDataInfoService.saveOrUpdate(matchDataInfo);
			}
		}
	}

}
