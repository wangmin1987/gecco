package com.isport.crawl.cctv;

import org.springframework.stereotype.Service;
 
/**
 * 央视英格兰
 * http://sports.cctv.com/special/premierleague/videos/index.shtml
 * @author 八斗体育
 *
 */
@Service
public class PremierleagueCrawl extends FbvideoCrawl{ 
	 
}
