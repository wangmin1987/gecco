package com.isport.crawl.tengxun.broadcast;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.isport.bean.MatchCategoryInfo;
import com.isport.utils.DateUtils;

/**
 * 赛事分类信息抓取
 * http://matchweb.sports.qq.com/matchUnion/cateColumns?from=pc&callback=getGameNavDataCallback
 * 
 * @author 八斗体育
 *
 */
@Service
public class MatchCategoryInfoCrawl extends MatchCrawl {
	public void crawl() {
		String url = "http://matchweb.sports.qq.com/matchUnion/cateColumns?from=pc&callback=getGameNavDataCallback";
		String gson = get(url); // 请求网络
		List<MatchCategoryInfo> matchCategoryInfoes = parse(gson); // 解析字符串
		for (MatchCategoryInfo matchCategoryInfo : matchCategoryInfoes) {
			if (matchCategoryInfoService.saveOrUpdate(matchCategoryInfo)) // 存储
				System.out.println("插入成功" + matchCategoryInfo.getMatchName());
		}
	}

	private List<MatchCategoryInfo> parse(String gson) {
		gson = clean(gson);
		List<MatchCategoryInfo> matchCategoryInfoes = new ArrayList<MatchCategoryInfo>();
		JSONObject jsonObject = JSONObject.parseObject(gson);
		JSONArray data = jsonObject.getJSONArray("data");
		for (Object obj : data) {
			jsonObject = JSONObject.parseObject(obj.toString());
			String title = jsonObject.getString("title"), channel = channels.get(title);
			JSONArray columns = jsonObject.getJSONArray("columns");
			for (Object column : columns) {
				MatchCategoryInfo matchCategoryInfo = new MatchCategoryInfo();
				jsonObject = JSONObject.parseObject(column.toString());
				matchCategoryInfo.setChannelId(channel);
				matchCategoryInfo.setColumnId(jsonObject.getString("columnId"));
				matchCategoryInfo.setIcon(jsonObject.getString("icon"));
				matchCategoryInfo.setMatchName(jsonObject.getString("name"));
				matchCategoryInfo.setCreateTime(DateUtils.getStrYYYYMMDDHHmmss(new Date()));
				matchCategoryInfo.setId(UUID.randomUUID().toString());
				matchCategoryInfoes.add(matchCategoryInfo);
			}
		}
		return matchCategoryInfoes;
	}

}
