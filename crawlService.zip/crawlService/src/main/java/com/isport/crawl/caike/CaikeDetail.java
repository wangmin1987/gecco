package com.isport.crawl.caike;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.isport.Constants;
import com.isport.bean.NewsInfoBean;
import com.isport.crawl.AbstractDetailPipeLine;

@Service
public class CaikeDetail extends AbstractDetailPipeLine{

	@Override
	protected void setParseParameter(NewsInfoBean newsInfoBean, JSONObject jo) throws Exception {
		// 获取标题
				String title = jo.getString("title");
				// 获取发布时间  彩客网编辑&nbsp;&nbsp;发表于：2018-12-07 16:47&nbsp;&nbsp;&nbsp;&nbsp;来源：互联网
				String pubDate = jo.getString("pubDate");
				if(pubDate!=null && pubDate!="") {
					int pos1 = pubDate.indexOf("发表于：")+4;
					int pos2 = pubDate.indexOf("来源", pos1);
					if(pos1>0 && pos2>0) {
						pubDate = pubDate.substring(pos1, pos2) + ":00";
					}
				}
				newsInfoBean.setTitle(title);
				newsInfoBean.setPub_date(pubDate);
	}

	@Override
	protected void setConstant(NewsInfoBean newsInfoBean) {
		newsInfoBean.setSource(Constants.NEWS_SOURCE_Caike.value);
		newsInfoBean.setSource_icon(Constants.NEWS_ICON_Caike.value);
		
	}

	@Override
	protected String getBodyExpession() {
		return "#_articleContent_";
	}

}
