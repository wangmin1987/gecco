package com.isport.crawl.entrance;
 

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.isport.bean.MatchCategoryInfo;
import com.isport.crawl.distribute.CrawlService;
import com.isport.crawl.distribute.SchedulerSingle;
import com.isport.crawl.distribute.TaskService;
import com.isport.crawl.tengxun.broadcast.AdviceService;
import com.isport.crawl.tengxun.broadcast.LsAllTypesCrawl;
import com.isport.crawl.tengxun.broadcast.MatchCategoryInfoCrawl;
import com.isport.crawl.tengxun.broadcast.MatchDataInfoCrawl;
import com.isport.crawl.tengxun.broadcast.MatchInfoCrawl;
import com.isport.crawl.video.VideoService;

@Service
public class CrawlEntrance {
	@Autowired
	CrawlService crawlService;
 
	@Autowired
	SchedulerSingle schedulerSingle;

	@Autowired
	VideoService videoService;
	
	@Autowired
	MatchCategoryInfoCrawl matchCategoryInfoCrawl;
	
	@Autowired
	MatchInfoCrawl matchInfoCrawl;
	
	@Autowired
	MatchDataInfoCrawl matchDataInfoCrawl;
	
	@Autowired 
	LsAllTypesCrawl lsAllTypesCrawl;

//	@Async
//	//@Scheduled(fixedDelay = 1000 * 60 * 60*300)
//	@PostConstruct
//	public void crawlServiceEntrance() {
//		System.out.println("crawlService CrawlEntrance....");
//		crawlService.crawl();
//	}
//	
//	@Async
//	@Scheduled(fixedDelay = 1000 * 60*30)
//	public void taskServiceCrawlEntrance() {
//		System.out.println("TaskService.create()....");
//		TaskService.create()
//		.scheduler(schedulerSingle.getInstance())
//		.start();
//	}
	
//	@Autowired
//	AdviceService adviceService;
//	@Async
//	@Scheduled(fixedDelay = 1000 * 60 )
//	public void testCrawlServiceCrawlEntrance() {
//		System.out.println("test....");
//		adviceService.adviceTest();
//	}
//	@Async
//	@Scheduled(fixedDelay = 1000 * 60 * 60 * 300)
//	public void broadcastCrawlServiceCrawlEntrance() {
//		System.out.println("CategoryInfo....");
//		matchCategoryInfoCrawl.crawl();
//	}
//	@Async
//	@Scheduled(fixedDelay = 1000 * 60*2)
//	public void matchInfoCrawlServiceCrawlEntrance() {
//		System.out.println("matchInfoCrawl....");
////		matchInfoCrawl.crawl("e5e4aa2ca8864c97a589b9d798a75eb6","208");
//		matchInfoCrawl.crawl();
//	}
//	
//	@Async
//	@Scheduled(fixedDelay = 1000 * 60*30)
//	public void matchDataInfoCrawlFinishedServiceCrawlEntrance() {
//		System.out.println("matchDataInfoCrawl finished....");
//		matchDataInfoCrawl.crawlFinished();
//	}
//	@Async
//	@Scheduled(fixedDelay = 1000 * 30)
//	public void matchDataInfoCrawlInServiceCrawlEntrance() {
//		System.out.println("matchDataInfoCrawl in....");
//		matchDataInfoCrawl.crawlIn();
//	}
//
//	@Async
//	@Scheduled(fixedDelay = 1000 *30)
//	public void lsCrawlServiceCrawlEntrance() {
//		System.out.println("LsCrawl....");
////		lsAllTypesCrawl.crawlIn();
//		lsAllTypesCrawl.crawlType();
//	}
	
	
//	@Async
//	@Scheduled(fixedDelay = 1000 * 60 * 60 * 72)
////	@PostConstruct
//	public void cctvcrawlServiceEntrance() {
//		System.out.println("cctv crawlService CrawlEntrance....");
////		videoService.crawlzq();
//		videoService.crawlcctvfb();
//	}
	
	@Async
	@Scheduled(fixedDelay = 1000 * 60 * 60 * 72)
//	@PostConstruct
	public void zqcrawlServiceEntrance() {
		System.out.println("zq crawlService CrawlEntrance....");
		videoService.crawlzq();
	}

//	@Async
//	@Scheduled(fixedDelay = 1000 * 60 * 60 * 72)
////	@PostConstruct
//	public void lqcrawlServiceEntrance() {
//		System.out.println("lq crawlService CrawlEntrance....");
//		videoService.crawllq();
//	}

//	@Async
//	@Scheduled(fixedDelay = 1000 * 60 * 60*300)
////	@PostConstruct
//	public void djcrawlServiceEntrance() {
//		System.out.println("dj crawlService CrawlEntrance....");
//		videoService.crawldj();
//	}
}
