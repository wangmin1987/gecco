package com.isport.crawl.cctv;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.springframework.stereotype.Service;
 

/**
 * 央视意大利足球 http://sports.cctv.com/special/seriea/videos/
 * 
 * @author 八斗体育
 *
 */
@Service
public class SerieaCrawl extends FbvideoCrawl {

	@Override
	protected List<String> getDetails(WebDriver driver) {
		List<String> urls = new ArrayList<String>();
		try {
			Thread.sleep(1000 * 5);
			List<WebElement> uls = driver.findElements(By.cssSelector("div.image_list_box02 ul"));
			System.out.println(": uls:" + uls.size());
			for (int i = 0; i < uls.size(); i++) {
				WebElement webElement = uls.get(i);
				List<WebElement> lies = webElement.findElements(By.tagName("li"));
				System.out.println("lies:" + lies.size());
				for (WebElement li : lies) {
					WebElement href = li.findElement(By.cssSelector("div.image a"));
					String url = href.getAttribute("href");
					urls.add(url);
					String src = li.findElement(By.cssSelector("div.image img")).getAttribute("src");
					titleImgs.put(url, src);
				}
			}
			System.out.println("urls1:" + urls.size());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return urls;
	}
 
}
