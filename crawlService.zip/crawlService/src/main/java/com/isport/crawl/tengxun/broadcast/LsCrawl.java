package com.isport.crawl.tengxun.broadcast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isport.bean.MatchInfo;

/**
 * 
 * @author 八斗体育
 *
 */
@Service
public abstract class LsCrawl extends MatchCrawl {
	@Autowired
	AdviceService adviceService;

	/**
	 * 抓取匹配一个
	 * 
	 * @param matchInfo
	 */
	public abstract void crawl(MatchInfo matchInfo);

	public abstract List<MatchBean> parse(String html, MatchInfo matchInfo);

	/**
	 * 抓取匹配一类
	 * 
	 * @param matchInfo
	 */
	public abstract void crawl(List<MatchInfo> matchInfoes);

	/**
	 * 赛事比对， 是否同一个
	 * 
	 * @param matchBean
	 * @param matchInfo
	 * @return
	 */
	protected boolean compare(MatchBean matchBean, MatchInfo matchInfo) {
		String left = matchBean.getHome(), right = matchBean.getAway(), leftm = matchInfo.getLeftName(),
				rightm = matchInfo.getRightName(), startTime = matchBean.getStartTime(),
				startTimem = matchInfo.getStartDate();
		if (left.equals(leftm) || right.equals(rightm)) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
			try {
				Calendar cale = null;
				cale = Calendar.getInstance();
				int year = cale.get(Calendar.YEAR);
				startTime = year + "-" + startTime;
				long start = sdf.parse(startTime).getTime();
				sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				long startm = sdf.parse(startTimem).getTime();
				if (start == startm) {
					System.out.println("compared:" + left + "," + right + "," + start);
					return true;
				} else {
					System.out.println("failed:" + left + "," + right + "," + startTime + "," + startTimem);
					return false;
				}
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return false;
	}
	 
}
