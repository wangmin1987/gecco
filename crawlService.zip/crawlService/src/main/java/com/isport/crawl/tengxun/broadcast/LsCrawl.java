package com.isport.crawl.tengxun.broadcast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.isport.bean.MatchDataInfo;
import com.isport.bean.MatchInfo;
import com.isport.utils.DateUtils;

/**
 * https://www.leisu.com/
 * 
 * @author 八斗体育
 *
 */
@Service
public class LsCrawl extends MatchCrawl {
	@Autowired
	AdviceService adviceService;

	public void crawlIn() {
		System.out.println("crawlIn");
		List<MatchInfo> matchInfos = matchInfoService.getAll("1");
		System.out.println(matchInfos.size());
		for (MatchInfo matchInfo : matchInfos) {
			try {
				String zqchannelId = channels.get("足球"),
						lqchannelId = channels.get("篮球"),
						miChannel = matchInfo.getChannelId();
				if (zqchannelId.equals(miChannel)) {
					inzq(matchInfo);
//				}else if(lqchannelId.equals(miChannel)) {
//					inlq(matchInfo);
				}
				updateMatchStat(matchInfo);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

	}

	private void inlq(MatchInfo matchInfo) { 
		String url = "https://www.leisu.com/";
		String html = get(url);
		System.out.println("Request:" + url);
		final String id = matchInfo.getId();
		List<MatchBean> matchBeans = parselq(html, matchInfo);
		for (MatchBean matchBean : matchBeans) {
			html = get(matchBean.getDetail());
			JSONObject jsonObject = JSONObject.parseObject(html);
			JSONArray jsonArray = jsonObject.getJSONObject("data").getJSONArray("tlive");
			MatchDataInfo matchDataInfo = new MatchDataInfo();
			matchDataInfo.setMatchData(jsonArray.toString());
			matchDataInfo.setDataType("0");
			matchDataInfo.setId(UUID.randomUUID().toString());
			matchDataInfo.setDataSource(matchBean.getDetail());
			matchDataInfo.setMatchId(id);
			matchDataInfo.setUpdateDate(DateUtils.getStrYYYYMMDDHHmmss(new Date()));
			matchDataInfo.setMatchType("0");
			matchDataInfoService.saveOrUpdate(matchDataInfo);
			// 更新通知
			adviceService.advice(matchDataInfo);
		} 
	}

	private List<MatchBean> parselq(String html, MatchInfo matchInfo) { 
		Document document = Jsoup.parse(html);
		Elements elements = document.select("div.children.live table.table.times-lot").select("tr");
		List<MatchBean> matchBeans = new ArrayList<MatchBean>();
		System.out.println(matchBeans.size());
		for (Element element : elements) {
			MatchBean matchBean = new MatchBean();
			String startTime = element.select("td.time").text(); 
			String home = element.select("td.home div span").text();
			String away = element.select("td.away div span").text();
			System.out.println(home);
			System.out.println(away);
			System.out.println(startTime);
			String sid = element.attr("data-id");
			matchBean.setStartTime(startTime);
			matchBean.setHome(home);
			matchBean.setAway(away);
			if (compare(matchBean, matchInfo)) {
//			if(home.equals("泽维卡平联")) {
				String detail = "http://api.leisu.com/app/live/matchdetail?sid=" + sid;
				matchBean.setDetail(detail);
				matchBeans.add(matchBean);
			}
		}
		return matchBeans; 
	}

	private void updateMatchStat(MatchInfo matchInfo) {
		// 未匹配到的过期数据更新
		String startDate = matchInfo.getStartDate();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			long time = sdf.parse(startDate).getTime();
			if (time + 12 * 1000 * 60 * 60 - System.currentTimeMillis() < 0) {
				String matchStat = "2", mid = matchInfo.getMid();
				matchInfoService.updateMatchStat(matchStat, mid);
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	private class MatchBean {
		private String startTime;
		private String home;
		private String away;
		private String detail;

		public String getDetail() {
			return detail;
		}

		public void setDetail(String detail) {
			this.detail = detail;
		}

		public String getStartTime() {
			return startTime;
		}

		public void setStartTime(String startTime) {
			this.startTime = startTime;
		}

		public String getHome() {
			return home;
		}

		public void setHome(String home) {
			this.home = home;
		}

		public String getAway() {
			return away;
		}

		public void setAway(String away) {
			this.away = away;
		}
	}

	private void inzq(MatchInfo matchInfo) {
		String url = "https://www.leisu.com/";
		String html = get(url);
		System.out.println("Request:" + url);
		final String id = matchInfo.getId();
		List<MatchBean> matchBeans = parse(html, matchInfo);
		for (MatchBean matchBean : matchBeans) {
			html = get(matchBean.getDetail());
			JSONObject jsonObject = JSONObject.parseObject(html);
			JSONArray jsonArray = jsonObject.getJSONArray("event");
			MatchDataInfo matchDataInfo = new MatchDataInfo();
			matchDataInfo.setMatchData(jsonArray.toString());
			matchDataInfo.setDataType("0");
			matchDataInfo.setId(UUID.randomUUID().toString());
			matchDataInfo.setDataSource(matchBean.getDetail());
			matchDataInfo.setMatchId(id);
			matchDataInfo.setUpdateDate(DateUtils.getStrYYYYMMDDHHmmss(new Date()));
			matchDataInfo.setMatchType("0");
			matchDataInfoService.saveOrUpdate(matchDataInfo);
			// 更新通知
			adviceService.advice(matchDataInfo);
		}
	}

	private List<MatchBean> parse(String html, MatchInfo matchInfo) {
		Document document = Jsoup.parse(html);
		Elements elements = document.select("div.children.live table.table.times-lot").select("tr");
		List<MatchBean> matchBeans = new ArrayList<MatchBean>();
		System.out.println(matchBeans.size());
		for (Element element : elements) {
			MatchBean matchBean = new MatchBean();
			String startTime = element.select("td.time").text(); 
			String home = element.select("td.home a span").text();
			String away = element.select("td.away a span").text();
			System.out.println(home);
			System.out.println(away);
			System.out.println(startTime);
			String sid = element.attr("data-id");
			matchBean.setStartTime(startTime);
			matchBean.setHome(home);
			matchBean.setAway(away);
			if (compare(matchBean, matchInfo)) { 
				String detail = "http://api.leisu.com/app/live/matchdetail?sid=" + sid;
				matchBean.setDetail(detail);
				matchBeans.add(matchBean);
			}
		}
		return matchBeans;
	}

	public static void main(String[] args) {
		// 未匹配到的过期数据更新
		String startDate = "2018-12-14 16:50:00";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			long time = sdf.parse(startDate).getTime();
			if (time + 12 * 1000 * 60 * 60 - System.currentTimeMillis() < 0) {
				System.out.println("update");
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	private boolean compare(MatchBean matchBean, MatchInfo matchInfo) {
		String left = matchBean.getHome(), right = matchBean.getAway(), leftm = matchInfo.getLeftName(),
				rightm = matchInfo.getRightName(), startTime = matchBean.getStartTime(),
				startTimem = matchInfo.getStartDate();
		System.out.println("compare");
		if (left.equals(leftm)) {
			if (right.equals(rightm)) {
				SimpleDateFormat sdf = new SimpleDateFormat("MM-dd HH:mm");
				try {
					long start = sdf.parse(startTime).getTime();
					sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					long startm = sdf.parse(startTimem).getTime();
					System.out.println(start);
					System.out.println(startm);
					if (start == startm) {
						return true;
					}
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}
}
