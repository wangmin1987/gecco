package com.isport.crawl.q433;

import org.springframework.stereotype.Service;

import com.geccocrawler.gecco.dynamic.DynamicGecco;

@Service
public class Q433Crawl {
	
	public void register() {
		Class<?> newsBriefs = DynamicGecco.html().stringField("docUrl").csspath("a").attr("href").build()
				.stringField("pubDate").csspath("div.ot span:eq(2)").text().build().register();
		
		DynamicGecco.html()
		.gecco(new String[] { "http://www.11player.com/txzq/cp/zqjc/","http://www.11player.com/txzq/cp/zqjc/list_{page}.html"}, "playerList")
		.requestField("request").request().build().listField("newsList", newsBriefs).csspath("div.news_list ul").build()
		.stringField("nextUrl").csspath("ul.pagination li:last-child a").attr("href").build().register();
	
		DynamicGecco.html().gecco(new String[] {"http://www.11player.com/txzq/cp/zqjc/20{id}.html"}, "playerDetail").requestField("request").request().build()
		.stringField("content").csspath("html").build()
		.stringField("title").csspath("h1").text().build()
		.stringField("pubDate").csspath("div.times h5").text().build().register();
	}

}
