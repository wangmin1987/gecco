package com.isport.utils;

import java.lang.reflect.Field;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.util.HtmlUtils;

public class HtmlUtil {
	private static final String regEx_script = "<script[^>]*?>[\\s\\S]*?<\\/script>"; // 定义script的正则表达式
    private static final String regEx_style = "<style[^>]*?>[\\s\\S]*?<\\/style>"; // 定义style的正则表达式
    private static final String regEx_html = "<[^>]+>"; // 定义HTML标签的正则表达式
    private static final String regEx_space = "\\s*|\t|\r|\n";//定义空格回车换行符
    //private static final String regEx_p = "<[a-zA-Z]+.*?>([\s\S]*?)</[a-zA-Z]*>";//定义空格回车换行符
    
    /**
     * @param htmlStr
     * @return
     *  删除Html标签
     */
    public static String delHTMLTag(String htmlStr) {
        Pattern p_script = Pattern.compile(regEx_script, Pattern.CASE_INSENSITIVE);
        Matcher m_script = p_script.matcher(htmlStr);
        htmlStr = m_script.replaceAll(""); // 过滤script标签

        Pattern p_style = Pattern.compile(regEx_style, Pattern.CASE_INSENSITIVE);
        Matcher m_style = p_style.matcher(htmlStr);
        htmlStr = m_style.replaceAll(""); // 过滤style标签

        Pattern p_html = Pattern.compile(regEx_html, Pattern.CASE_INSENSITIVE);
        Matcher m_html = p_html.matcher(htmlStr);
        htmlStr = m_html.replaceAll(""); // 过滤html标签

        Pattern p_space = Pattern.compile(regEx_space, Pattern.CASE_INSENSITIVE);
        Matcher m_space = p_space.matcher(htmlStr);
        htmlStr = m_space.replaceAll(""); // 过滤空格回车标签
        
//        Pattern p_p = Pattern.compile(regEx_p, Pattern.CASE_INSENSITIVE);
//        Matcher m_p_p = p_p.matcher(htmlStr);
//        htmlStr = m_p_p.replaceAll(""); // 过滤空格回车标签
        return htmlStr.trim(); // 返回文本字符串
    }
    
    public static String getTextFromHtml(String htmlStr){
    	htmlStr = delHTMLTag(htmlStr);
    	htmlStr = htmlStr.replaceAll("&nbsp;", "");
    	//htmlStr = htmlStr.substring(0, htmlStr.indexOf("。")+1);
    	return htmlStr;
    }
    /**
     * 将list中包含对象的所有字符串属性取消转义
     * @param list
     * @param <T>
     * @return
     */
    public static <T> List<T> listHtmlUnEscape(List<T> list) {
        return listHtmlTextHandle(list, 0);
    }
 
    /**
     * 将list中包含对象的所有字符串属性添加转义
     * @param list
     * @param <T>
     * @return
     */
    public static <T> List<T> listHtmlEscape(List<T> list) {
        return listHtmlTextHandle(list, 1);
    }
 
    /**
     * 将对象中的所有字符串属性取消转义
     * @param t
     * @param <T>
     * @return
     */
    public static <T> T objectHtmlUnEscape(T t) {
        return objectHtmlTextHandle(t, 0);
    }
 
    /**
     * 将对象中的所有字符串属性添加转义
     * @param t
     * @param <T>
     * @return
     */
    public static <T> T objectHtmlEscape(T t) {
        return objectHtmlTextHandle(t, 1);
    }
 
    /**
     * list中的对象属性值批量html转义
     * @param list 需要做转义操作的list
     * @param option 0 取消转义 1 转义
     * @param <T>
     * @return
     */
    public static <T> List<T> listHtmlTextHandle(List<T> list, int option) {
        for (int i = 0; i < list.size(); i++) {
            T t = list.get(i);
            list.remove(i); // 先移除原有的对象
            t = 0 == option ? objectHtmlUnEscape(t) : objectHtmlEscape(t);
            list.add(i, t); // 再将取消转义后的对象添加到list对应位置
        }
        return list;
    }
 
    /**
     * 对象属性值批量html转义
     * @param t 需要做转义操作的对象
     * @param option 0 取消转义 1 转义
     * @param <T>
     * @return
     */
    public static <T> T objectHtmlTextHandle(T t, int option) {
        Class clazz = t.getClass();
        Field[] fields = clazz.getDeclaredFields();
        for (Field field : fields) {
            Class type = field.getType();
            if (type.equals(String.class)) {
                field.setAccessible(true);
                try {
                    String filedValue = (String) field.get(t);
                    // 进行取消转义（0），转义（1）操作
                    filedValue = 0 == option ? htmlUnescape(filedValue) : htmlEscape(filedValue);
                    field.set(t, filedValue);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return t;
    }
 
    /**
     * Spring的HtmlUtils进行转义
     */
    public static String htmlEscape(String str) {
        if (StringUtils.isBlank(str)) {
            return null;
        } else {
            return HtmlUtils.htmlEscape(str);
        }
    }
 
    /**
     * Spring的HtmlUtils进行还原
     */
    public static String htmlUnescape(String str) {
        if (StringUtils.isBlank(str)) {
            return null;
        } else {
            return HtmlUtils.htmlUnescape(str);
        }
    } 
    
    public static void main(String[] args) {
    	String str = "<img src=\"\\&quot;http://e0.ifengimg.com/08/2018/1206/012901110E67A58996C18E81EB45B0D45DECE0D7_size1790_w686_h667.png\\&quot;\">";
		System.out.println(StringEscapeUtils.unescapeHtml(str));
		str = StringEscapeUtils.unescapeHtml(str);
		System.out.println(str.replace("\\\"", ""));
	}
}
