package com.isport.service.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.isport.bean.MatchDataInfo;
import com.isport.utils.StringUtils;

@Service
public class MatchDataInfoService {
	@Autowired
	JdbcTemplate jdbcTemplate;

	public boolean saveOrUpdate(MatchDataInfo matchDataInfo) {
		if (exist(matchDataInfo)) {
			return update(matchDataInfo);
		} else {
			return insert(matchDataInfo);
		} 
	}

	private boolean insert(MatchDataInfo matchDataInfo) {
		String sql = "INSERT INTO MATCH_DATA_INFO(ID,MATCH_ID,MATCH_TYPE,DATA_TYPE,DATA_SOURCE_URL,MATCH_DATA,"
				+ "UPDATE_DATE) VALUES(?,?,?,?,?,?,?);";
		try {
			jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setString(1, StringUtils.md5(matchDataInfo.getId()));
					ps.setString(2, matchDataInfo.getMatchId());
					ps.setString(3, matchDataInfo.getMatchType());
					ps.setString(4, matchDataInfo.getDataType());
					ps.setString(5, matchDataInfo.getDataSource());
					ps.setString(6, matchDataInfo.getMatchData());
					ps.setString(7, matchDataInfo.getUpdateDate());
				}

				@Override
				public int getBatchSize() {
					return 1;
				}
			});
			System.out.println("MatchDataInfoService 插入成功" +matchDataInfo.getMatchId());
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	private boolean update(MatchDataInfo matchDataInfo) {
		String sql = "UPDATE MATCH_DATA_INFO SET MATCH_TYPE=?,DATA_SOURCE_URL=?,MATCH_DATA=?"
				+ ",UPDATE_DATE=? WHERE MATCH_ID=? AND DATA_TYPE =? ";
		jdbcTemplate.update(sql, new Object[] {matchDataInfo.getMatchType(),
				matchDataInfo.getDataSource(),matchDataInfo.getMatchData()
				,matchDataInfo.getUpdateDate(),matchDataInfo.getMatchId(),matchDataInfo.getDataType()});
		System.out.println("MatchDataInfoService 更新成功" + matchDataInfo.getMatchId());
		return true;
	}

	private boolean exist(MatchDataInfo matchDataInfo) {
		String sql = "SELECT COUNT(*) FROM MATCH_DATA_INFO WHERE MATCH_ID = '" + matchDataInfo.getMatchId()+"'"
				+ " AND DATA_TYPE = "+matchDataInfo.getDataType();
		return jdbcTemplate.queryForObject(sql, Integer.class) != 0;
	}

	public String findDataInfo(MatchDataInfo matchDataInfo) {
		String sql = "SELECT MATCH_DATA FROM MATCH_DATA_INFO WHERE MATCH_ID = '" + matchDataInfo.getMatchId()+"'"
				+ " AND DATA_TYPE = "+matchDataInfo.getDataType();
		return jdbcTemplate.queryForObject(sql, String.class);
	}
}
