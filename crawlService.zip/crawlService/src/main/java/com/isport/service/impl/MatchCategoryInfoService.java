package com.isport.service.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.isport.bean.MatchCategoryInfo;
import com.isport.bean.MatchDataInfo; 
/**
 * 
 * @author 八斗体育
 *
 */
@Service
public class MatchCategoryInfoService {
	@Autowired
	JdbcTemplate jdbcTemplate; 
	
	public List<MatchCategoryInfo> getAll() {
		String sql = "SELECT ID,COLUMN_ID,CHANNEL_ID,ICON,MATCH_NAME,CREATE_DATE FROM MATCH_CATEGORY_INFO";
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
		List<MatchCategoryInfo> matchCategoryInfoes = new ArrayList<MatchCategoryInfo>();
		for (int i = 0; i < rows.size(); i++) {
			Map<String, Object> categoryMap = rows.get(i);
			MatchCategoryInfo matchCategoryInfo = new MatchCategoryInfo();
			matchCategoryInfo.setId(String.valueOf(categoryMap.get("ID")));
			matchCategoryInfo.setColumnId(String.valueOf(categoryMap.get("COLUMN_ID")));
			matchCategoryInfo.setChannelId(String.valueOf(categoryMap.get("CHANNEL_ID")));
			matchCategoryInfo.setIcon(String.valueOf(categoryMap.get("ICON")));
			matchCategoryInfo.setMatchName(String.valueOf(categoryMap.get("MATCH_NAME")));
			matchCategoryInfo.setCreateTime(String.valueOf(categoryMap.get("CREATE_DATE")));
			matchCategoryInfoes.add(matchCategoryInfo);
		}
		return matchCategoryInfoes;
	}

	public boolean save(MatchCategoryInfo matchCategoryInfo) {
		String sql = "INSERT INTO MATCH_CATEGORY_INFO(ID,COLUMN_ID,CHANNEL_ID,ICON,MATCH_NAME,CREATE_DATE) VALUES(?,?,?,?,?,?);";
		try {
			jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setString(1, matchCategoryInfo.getId());
					ps.setString(2, matchCategoryInfo.getColumnId());
					ps.setString(3, matchCategoryInfo.getChannelId());
					ps.setString(4, matchCategoryInfo.getIcon());
					ps.setString(5, matchCategoryInfo.getMatchName());
					ps.setString(6, matchCategoryInfo.getCreateTime());
				}

				@Override
				public int getBatchSize() {
					return 1;
				}
			});
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}
	 
	public boolean saveOrUpdate(MatchCategoryInfo matchCategoryInfo) {
		if (!exist(matchCategoryInfo)) {  
			return save(matchCategoryInfo);
		}else {
			return false;
		}
	}
 

	private boolean exist(MatchCategoryInfo matchCategoryInfo) {
		String sql = "SELECT COUNT(*) FROM MATCH_CATEGORY_INFO WHERE COLUMN_ID = '"+matchCategoryInfo.getColumnId()+"'";
		return jdbcTemplate.queryForObject(sql, Integer.class) != 0;
	}
}
