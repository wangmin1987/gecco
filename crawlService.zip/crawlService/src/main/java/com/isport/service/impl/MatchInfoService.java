package com.isport.service.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.isport.bean.MatchInfo;
import com.isport.utils.StringUtils;

@Service
public class MatchInfoService {
	@Autowired
	JdbcTemplate jdbcTemplate;

	public List<MatchInfo> getAll() {
		String sql = "SELECT ID,MID,START_DATE, MATCH_STATUS,LEFT_NAME,RIGHT_NAME,START_DATE FROM MATCH_INFO_T";
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
		List<MatchInfo> matchInfoes = new ArrayList<MatchInfo>();
		for (int i = 0; i < rows.size(); i++) {
			Map<String, Object> infoMap = rows.get(i);
			MatchInfo matchInfo = new MatchInfo();
			matchInfo.setId(String.valueOf(infoMap.get("ID")));
			matchInfo.setMid(String.valueOf(infoMap.get("MID")));
			matchInfo.setStartDate(String.valueOf(infoMap.get("START_DATE")));
			matchInfo.setMatchStat(String.valueOf(infoMap.get("MATCH_STATUS")));
			matchInfo.setLeftName(String.valueOf(infoMap.get("LEFT_NAME")));
			matchInfo.setRightName(String.valueOf(infoMap.get("RIGHT_NAME")));
			matchInfo.setStartDate(String.valueOf(infoMap.get("START_DATE")));
			matchInfoes.add(matchInfo);
		}
		return matchInfoes;
	}

	public boolean saveOrUpdate(MatchInfo matchInfo) {
		if (exist(matchInfo)) {
			return update(matchInfo);
		} else {
			return insert(matchInfo);
		}

	}

	private boolean update(MatchInfo matchInfo) {
		String sql = "UPDATE MATCH_INFO_T SET COLUMN_ID=?,CATEGORY_ID=?,CHANNEL_ID=?,"
				+ "MATCH_TYPE=?,MATCH_DESC=?,"
				+ "START_DATE=?,LEFT_ID=?,LEFT_NAME=?,LEFT_BADGE=?,LEFT_GOAL=?,RIGHT_ID=?,"
				+ "RIGHT_NAME=?,RIGHT_BADGE=?,RIGHT_GOAL=?,V_URL=?,DETAIL_URL=?,"
				+ "MATCH_STATUS=?,UPDATE_DATE=? WHERE MID =?;";
		jdbcTemplate.update(sql, new Object[] {matchInfo.getColumnId(), matchInfo.getCategoryId(),
				matchInfo.getChannelId(), matchInfo.getMatchType(), matchInfo.getMatchDesc(), matchInfo.getStartDate(),
				matchInfo.getLeftId(), matchInfo.getLeftName(), matchInfo.getLeftBadge(), matchInfo.getLeftGoal(),
				matchInfo.getRightId(), matchInfo.getRightName(), matchInfo.getRightBadge(), matchInfo.getRightGoal(),
				matchInfo.getvUrl(), matchInfo.getDetailUrl(), matchInfo.getMatchStat(), 
				matchInfo.getUpdateTime(), matchInfo.getMid() });
		System.out.println("MatchInfoService 更新成功" + matchInfo.getMid());
		return true;
	}

	private boolean insert(MatchInfo matchInfo) {
		String sql = "INSERT INTO MATCH_INFO_T(ID,COLUMN_ID,CATEGORY_ID,CHANNEL_ID,MATCH_TYPE,MATCH_DESC,"
				+ "MID,START_DATE,LEFT_ID,LEFT_NAME,LEFT_BADGE,LEFT_GOAL,RIGHT_ID,"
				+ "RIGHT_NAME,RIGHT_BADGE,RIGHT_GOAL,V_URL,DETAIL_URL,"
				+ "MATCH_STATUS,CREATE_DATE,UPDATE_DATE) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
		try {
			jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					ps.setString(1, StringUtils.md5(matchInfo.getId()));
					ps.setString(2, matchInfo.getColumnId());
					ps.setString(3, matchInfo.getCategoryId());
					ps.setString(4, matchInfo.getChannelId());
					ps.setString(5, matchInfo.getMatchType());
					ps.setString(6, matchInfo.getMatchDesc());
					ps.setString(7, matchInfo.getMid());
					ps.setString(8, matchInfo.getStartDate());
					ps.setString(9, matchInfo.getLeftId());
					ps.setString(10, matchInfo.getLeftName());
					ps.setString(11, matchInfo.getLeftBadge());
					ps.setString(12, matchInfo.getLeftGoal());
					ps.setString(13, matchInfo.getRightId());
					ps.setString(14, matchInfo.getRightName());
					ps.setString(15, matchInfo.getRightBadge());
					ps.setString(16, matchInfo.getRightGoal());
					ps.setString(17, matchInfo.getvUrl());
					ps.setString(18, matchInfo.getDetailUrl());
					ps.setString(19, matchInfo.getMatchStat());
					ps.setString(20, matchInfo.getCreateTime());
					ps.setString(21, matchInfo.getUpdateTime());
				}

				@Override
				public int getBatchSize() {
					return 1;
				}
			}); 
			System.out.println("MatchInfoService 插入成功" + matchInfo.getMid());
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean exist(MatchInfo matchInfo) {
		String sql = "SELECT COUNT(*) FROM MATCH_INFO_T WHERE MID = '" + matchInfo.getMid()+"'";
		return jdbcTemplate.queryForObject(sql, Integer.class) != 0;
	}

	public List<MatchInfo> getAll(String string) {
		String sql = "SELECT ID,MID,START_DATE, MATCH_STATUS,LEFT_NAME,RIGHT_NAME,START_DATE,CHANNEL_ID FROM MATCH_INFO_T"
				+ " WHERE MATCH_STATUS = '"+string+"'";
		System.out.println(sql);
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
		List<MatchInfo> matchInfoes = new ArrayList<MatchInfo>();
		for (int i = 0; i < rows.size(); i++) {
			Map<String, Object> infoMap = rows.get(i);
			MatchInfo matchInfo = new MatchInfo();
			matchInfo.setId(String.valueOf(infoMap.get("ID")));
			matchInfo.setMid(String.valueOf(infoMap.get("MID")));
			matchInfo.setStartDate(String.valueOf(infoMap.get("START_DATE")));
			matchInfo.setMatchStat(String.valueOf(infoMap.get("MATCH_STATUS")));
			matchInfo.setLeftName(String.valueOf(infoMap.get("LEFT_NAME")));
			matchInfo.setRightName(String.valueOf(infoMap.get("RIGHT_NAME")));
			matchInfo.setStartDate(String.valueOf(infoMap.get("START_DATE")));
			matchInfo.setChannelId(String.valueOf(infoMap.get("CHANNEL_ID")));
			matchInfoes.add(matchInfo);
		}
		return matchInfoes;
	}

	public void updateMatchStat(String string,String mid) {
		String sql = "UPDATE MATCH_INFO_T SET MATCH_STATUS='"+string+"' WHERE MID='"+mid+"'"; 
		jdbcTemplate.update(sql);
		System.out.println("MatchInfoService 更新成功" + mid); 
	}

	public List<MatchInfo> getAll(String matchStatus, String channel) {
		String sql = "SELECT ID,MID,START_DATE, MATCH_STATUS,LEFT_NAME,RIGHT_NAME,START_DATE,CHANNEL_ID FROM MATCH_INFO_T"
				+ " WHERE MATCH_STATUS = '"+matchStatus+"' AND CHANNEL_ID = '"+channel+"'";
		System.out.println(sql);
		List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
		List<MatchInfo> matchInfoes = new ArrayList<MatchInfo>();
		for (int i = 0; i < rows.size(); i++) {
			Map<String, Object> infoMap = rows.get(i);
			MatchInfo matchInfo = new MatchInfo();
			matchInfo.setId(String.valueOf(infoMap.get("ID")));
			matchInfo.setMid(String.valueOf(infoMap.get("MID")));
			matchInfo.setStartDate(String.valueOf(infoMap.get("START_DATE")));
			matchInfo.setMatchStat(String.valueOf(infoMap.get("MATCH_STATUS")));
			matchInfo.setLeftName(String.valueOf(infoMap.get("LEFT_NAME")));
			matchInfo.setRightName(String.valueOf(infoMap.get("RIGHT_NAME")));
			matchInfo.setStartDate(String.valueOf(infoMap.get("START_DATE")));
			matchInfo.setChannelId(String.valueOf(infoMap.get("CHANNEL_ID")));
			matchInfoes.add(matchInfo);
		}
		return matchInfoes;
	}
}
