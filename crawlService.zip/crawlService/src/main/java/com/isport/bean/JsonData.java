package com.isport.bean;

import java.util.List;
import java.util.Map;

public class JsonData {
	private String count;
private List<Map> articles;
public String getCount() {
	return count;
}
public void setCount(String count) {
	this.count = count;
}
public List<Map> getArticles() {
	return articles;
}
public void setArticles(List<Map> articles) {
	this.articles = articles;
}


}
