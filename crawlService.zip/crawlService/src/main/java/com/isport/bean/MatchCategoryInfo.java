package com.isport.bean;
/**
 * 赛事分类信息
 * @author 八斗体育
 *
 */
public class MatchCategoryInfo {
	private String id;
	private String columnId; //腾讯赛事分类ID
	private String channelId; //频道ID
	private String icon; //ICON
	private String matchName; //腾讯赛事分类名称
	private String createTime; //创建时间
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getColumnId() {
		return columnId;
	}
	public void setColumnId(String columnId) {
		this.columnId = columnId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public String getMatchName() {
		return matchName;
	}
	public void setMatchName(String matchName) {
		this.matchName = matchName;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	 
}
