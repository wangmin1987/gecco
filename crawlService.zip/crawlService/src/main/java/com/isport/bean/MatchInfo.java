package com.isport.bean;
/**
 * 赛程信息
 * @author 八斗体育
 *
 */
public class MatchInfo {
	private String id;
	private String columnId; // 腾讯赛事分类ID
	private String categoryId; //赛事分类ID
	private String channelId; //频道ID
	private String matchType; //赛事类型
	private String matchDesc; //赛事描述
	private String mid;
	private String startDate; //比赛开始时间
	private String leftId; //球队AID
	private String leftName; //球队A名称
	private String leftBadge; //球队ALOGO
	private String leftGoal; //球队A得分
	private String rightId; //球队BID
	private String rightName; //球队B名称
	private String rightBadge; //球队BLOGO
	private String rightGoal; //球队B得分
	private String vUrl;  //视频URL
	private String detailUrl; //详情URL
	private String matchStat; //赛事状态
	private String createTime; //创建时间
	private String updateTime; //修改时间
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getColumnId() {
		return columnId;
	}
	public void setColumnId(String columnId) {
		this.columnId = columnId;
	}
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getMatchType() {
		return matchType;
	}
	public void setMatchType(String matchType) {
		this.matchType = matchType;
	}
	public String getMatchDesc() {
		return matchDesc;
	}
	public void setMatchDesc(String matchDesc) {
		this.matchDesc = matchDesc;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getLeftId() {
		return leftId;
	}
	public void setLeftId(String leftId) {
		this.leftId = leftId;
	}
	public String getLeftName() {
		return leftName;
	}
	public void setLeftName(String leftName) {
		this.leftName = leftName;
	}
	public String getLeftBadge() {
		return leftBadge;
	}
	public void setLeftBadge(String leftBadge) {
		this.leftBadge = leftBadge;
	}
	public String getLeftGoal() {
		return leftGoal;
	}
	public void setLeftGoal(String leftGoal) {
		this.leftGoal = leftGoal;
	}
	public String getRightId() {
		return rightId;
	}
	public void setRightId(String rightId) {
		this.rightId = rightId;
	}
	public String getRightName() {
		return rightName;
	}
	public void setRightName(String rightName) {
		this.rightName = rightName;
	}
	public String getRightBadge() {
		return rightBadge;
	}
	public void setRightBadge(String rightBadge) {
		this.rightBadge = rightBadge;
	}
	public String getRightGoal() {
		return rightGoal;
	}
	public void setRightGoal(String rightGoal) {
		this.rightGoal = rightGoal;
	}
	public String getvUrl() {
		return vUrl;
	}
	public void setvUrl(String vUrl) {
		this.vUrl = vUrl;
	}
	public String getDetailUrl() {
		return detailUrl;
	}
	public void setDetailUrl(String detailUrl) {
		this.detailUrl = detailUrl;
	}
	public String getMatchStat() {
		return matchStat;
	}
	public void setMatchStat(String matchStat) {
		this.matchStat = matchStat;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	} 
}
