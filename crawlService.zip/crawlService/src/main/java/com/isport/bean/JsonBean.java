package com.isport.bean;

public class JsonBean {
private Object response;
private JsonData data;

public Object getResponse() {
	return response;
}

public void setResponse(String response) {
	this.response = response;
}
public JsonData getData() {
	return data;
}

public void setData(JsonData data) {
	this.data = data;
}


}
