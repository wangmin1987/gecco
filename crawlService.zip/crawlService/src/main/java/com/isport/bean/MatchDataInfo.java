package com.isport.bean;
/**
 * 赛程数据信息
 * @author 八斗体育
 *
 */
public class MatchDataInfo {
	private String id;
	private String matchId; //赛事ID
	private String matchType; //赛事类型
	private String dataType;//数据类型
	private String dataSource; //数据源地址
	private String matchData; //赛程数据
	private String updateDate; //更新时间
	
	@Override
	public String toString() {
		return "id:"+id+",matchId:"+matchId+",matchType:"+matchType+",dataType:"+dataType+",dataSource:"+dataSource
				+"matchData:"+matchData+",updateDate:"+updateDate;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMatchId() {
		return matchId;
	}
	public void setMatchId(String matchId) {
		this.matchId = matchId;
	}
	public String getMatchType() {
		return matchType;
	}
	public void setMatchType(String matchType) {
		this.matchType = matchType;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getDataSource() {
		return dataSource;
	}
	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
	public String getMatchData() {
		return matchData;
	}
	public void setMatchData(String matchData) {
		this.matchData = matchData;
	}
	public String getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	} 
}
