package com.geccocrawler.gecco.spider.render;

public enum RenderType {
	
	HTML, JSON, XML
	
}
