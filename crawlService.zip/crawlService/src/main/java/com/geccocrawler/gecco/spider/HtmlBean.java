package com.geccocrawler.gecco.spider;

public interface HtmlBean extends SpiderBean {

}
