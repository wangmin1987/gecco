package com.geccocrawler.gecco.spider;

/**
 * 需要渲染的bean的基础接口
 * 
 * @author huchengyi
 *
 */
public interface SpiderBean extends java.io.Serializable {
	
}
