package com.geccocrawler.gecco.spider;

public interface JsonBean extends SpiderBean {

}
