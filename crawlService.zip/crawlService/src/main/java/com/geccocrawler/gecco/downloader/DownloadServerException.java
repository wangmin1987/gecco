package com.geccocrawler.gecco.downloader;

public class DownloadServerException extends DownloadException {

	private static final long serialVersionUID = -6268946015213051268L;

	public DownloadServerException(String message) {
		super(message);
	}

}
